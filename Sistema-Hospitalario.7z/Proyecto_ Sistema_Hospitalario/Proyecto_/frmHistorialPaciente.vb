Imports System.Data
Imports System.Data.OleDb

Public Class frmHistorialPaciente
    Public idpaciente As Integer
    Friend cmbHistoriales As OleDbCommandBuilder
    Friend daHistoriales As OleDbDataAdapter
    Friend dsHospital As DataSet
    Friend conexion As OleDbConnection
    Private cadenaConexion As String = _
                "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & _
                    Application.StartupPath & "\bdHospital.accdb'"



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()


    End Sub

    Private Sub frmHistorialPaciente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.conexion = New OleDbConnection(cadenaConexion)
        Me.dsHospital = New DataSet("dsHospital")


        Me.daHistoriales = New OleDbDataAdapter("SELECT tblHistoriales.idHistorial, tblHistoriales.idPaciente, tblPacientes.nombrePaciente, tblPacientes.apellidoPaciente, tblHistoriales.Enfermedad, tblHistoriales.Tratamiento, tblHistoriales.Fecha FROM tblPacientes INNER JOIN tblHistoriales ON tblPacientes.IdPaciente = tblHistoriales.idPaciente", conexion)
        Me.daHistoriales.Fill(Me.dsHospital, "tblHistoriales")
        Me.daHistoriales.FillSchema(Me.dsHospital.Tables("tblHistoriales"), SchemaType.Source)
        Me.cmbHistoriales = New OleDbCommandBuilder(Me.daHistoriales)


        Me.dsHospital.Tables("tblHistoriales").DefaultView.RowFilter = _
     "idPaciente= '" & Me.idpaciente & "'"

        Me.bdHistoriales.DataSource = Me.dsHospital.Tables("tblHistoriales")

        Me.dgvHistoriales.DataSource = Me.bdHistoriales
        Me.dgvHistoriales.ReadOnly = True

    End Sub

    Public Function obtneridpacienteHistoriales(ByVal idp As Integer) As Integer
        Me.idpaciente = idp

    End Function

    Private Sub btnGenerarReporte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenerarReporte.Click
        Dim MyDataSet As New DataSetHospital   'Conjunto de datos
        Dim MyDataTable As New DataSetHospital.tblHistorialesDataTable     'EL dataTable del conjunto de datos
        Dim mi_rptSocios As New CrystalReport4 'Documento cristal reports
        'Dim miReporte As New Form7 'Formulario visor
        Dim filas As Integer = Me.dgvHistoriales.Rows.Count
        Dim i As Integer = 0
        For i = 0 To filas - 2
            'Paso los datos al dataset el "DataGridViewTextBoxColumn" se encuentra dentro de
            ' la propiedad Columns(coleccion)>Dise�o>Name




            MyDataTable.Rows.Add(Me.dgvHistoriales.Rows(i).Cells("IdHistorial").Value _
            , Me.dgvHistoriales.Rows(i).Cells("nombrePaciente").Value _
            , Me.dgvHistoriales.Rows(i).Cells("apellidoPaciente").Value _
            , Me.dgvHistoriales.Rows(i).Cells("Enfermedad").Value _
             , Me.dgvHistoriales.Rows(i).Cells("Tratamiento").Value _
            , Me.dgvHistoriales.Rows(i).Cells("Fecha").Value)



        Next (i)
        '"Cliente" es la tabla en el dataset
        MyDataSet.Tables("tblHistoriales").Merge(MyDataTable)
        mi_rptSocios.SetDataSource(MyDataSet)
        My.Forms.fmrReporteHistorial.CrystalReportViewer1.ReportSource = mi_rptSocios
        My.Forms.fmrReporteHistorial.Show()
    End Sub

    Private Sub bdHistoriales_CurrentChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bdHistoriales.CurrentChanged

    End Sub
End Class