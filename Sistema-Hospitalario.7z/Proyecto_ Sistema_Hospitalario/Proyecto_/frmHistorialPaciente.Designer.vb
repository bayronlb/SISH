<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHistorialPaciente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.dgvHistoriales = New System.Windows.Forms.DataGridView
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblPaciente = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.btnGenerarReporte = New System.Windows.Forms.Button
        Me.bdHistoriales = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.dgvHistoriales, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bdHistoriales, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvHistoriales
        '
        Me.dgvHistoriales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHistoriales.Location = New System.Drawing.Point(12, 91)
        Me.dgvHistoriales.Name = "dgvHistoriales"
        Me.dgvHistoriales.Size = New System.Drawing.Size(649, 205)
        Me.dgvHistoriales.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(211, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(183, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Historial Medico de:"
        '
        'lblPaciente
        '
        Me.lblPaciente.AutoSize = True
        Me.lblPaciente.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaciente.Location = New System.Drawing.Point(390, 26)
        Me.lblPaciente.Name = "lblPaciente"
        Me.lblPaciente.Size = New System.Drawing.Size(82, 24)
        Me.lblPaciente.TabIndex = 1
        Me.lblPaciente.Text = "Paciente"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(107, 314)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(191, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Regresar a Manejo de Pacientes"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnGenerarReporte
        '
        Me.btnGenerarReporte.Location = New System.Drawing.Point(344, 314)
        Me.btnGenerarReporte.Name = "btnGenerarReporte"
        Me.btnGenerarReporte.Size = New System.Drawing.Size(191, 23)
        Me.btnGenerarReporte.TabIndex = 4
        Me.btnGenerarReporte.Text = "Generar Reporte para Paciente"
        Me.btnGenerarReporte.UseVisualStyleBackColor = True
        '
        'bdHistoriales
        '
        '
        'frmHistorialPaciente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(686, 376)
        Me.Controls.Add(Me.btnGenerarReporte)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblPaciente)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvHistoriales)
        Me.Name = "frmHistorialPaciente"
        Me.Text = "frmHistorialPaciente"
        CType(Me.dgvHistoriales, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bdHistoriales, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvHistoriales As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblPaciente As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents bdHistoriales As System.Windows.Forms.BindingSource
    Friend WithEvents btnGenerarReporte As System.Windows.Forms.Button
End Class
