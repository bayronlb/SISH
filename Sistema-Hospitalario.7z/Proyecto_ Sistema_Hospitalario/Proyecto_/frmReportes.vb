Imports System.Data
Imports System.Data.OleDb
Public Class frmReportes

    Friend dsHospital As DataSet
    Public controlador As Boolean = True
    Friend daPacientes As OleDbDataAdapter
    Friend daHistoriales As OleDbDataAdapter
    Friend daDoctores As OleDbDataAdapter
    Friend daCitas As OleDbDataAdapter
    Friend daCupos As OleDbDataAdapter
    Friend daEspecialidades As OleDbDataAdapter


    Friend cmbPacientes As OleDbCommandBuilder
    Friend cmbHistoriales As OleDbCommandBuilder
    Friend cmbDoctores As OleDbCommandBuilder
    Friend cmbCitas As OleDbCommandBuilder
    Friend cmbCupos As OleDbCommandBuilder
    Friend cmbEspecialidades As OleDbCommandBuilder
    Friend conexion As OleDbConnection

    Private cadenaConexion As String = _
                "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & _
                    Application.StartupPath & "\bdHospital.accdb'"

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
        My.Forms.frmAdministrador.Show()
    End Sub

    Private Sub frmReportes_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        'Me.btnSalir.PerformClick()
    End Sub

    Private Sub frmReportes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.conexion = New OleDbConnection(cadenaConexion)
        Me.dsHospital = New DataSet("dsHospital")

        Me.daPacientes = New OleDbDataAdapter("SELECT * FROM tblPacientes", Me.conexion)
        Me.daPacientes.Fill(Me.dsHospital, "tblPacientes")
        Me.daPacientes.FillSchema(Me.dsHospital.Tables("tblPacientes"), SchemaType.Source)
        Me.cmbPacientes = New OleDbCommandBuilder(Me.daPacientes)


        Me.daHistoriales = New OleDbDataAdapter("SELECT * FROM tblHistoriales", conexion)
        Me.daHistoriales.Fill(Me.dsHospital, "tblHistoriales")
        Me.daHistoriales.FillSchema(Me.dsHospital.Tables("tblHistoriales"), SchemaType.Source)
        Me.cmbHistoriales = New OleDbCommandBuilder(Me.daHistoriales)


        Me.daDoctores = New OleDbDataAdapter("SELECT tblDoctores.IdDoctor, tblDoctores.nombreDoctor, tblDoctores.apellidoDoctor, tblDoctores.correoDoctor, tblDoctores.Direccion, tblDoctores.Telefono, tblDoctores.Especialidad, tblDoctores.Estado,tblEspecialidades.Especialidad FROM tblEspecialidades INNER JOIN tblDoctores ON tblEspecialidades.IdEspecialidad = tblDoctores.Especialidad", conexion)
        Me.daDoctores.Fill(Me.dsHospital, "tblDoctores")
        Me.daDoctores.FillSchema(Me.dsHospital.Tables("tblDoctores"), SchemaType.Source)
        Me.cmbDoctores = New OleDbCommandBuilder(Me.daDoctores)

        Me.daCitas = New OleDbDataAdapter("SELECT tblCitas.IdCitas, tblCitas.idPaciente, tblCitas.idDoctor, tblCitas.Fecha, tblDoctores.nombreDoctor, tblDoctores.apellidoDoctor, tblPacientes.nombrePaciente, tblPacientes.apellidoPaciente FROM tblPacientes INNER JOIN (tblDoctores INNER JOIN tblCitas ON tblDoctores.IdDoctor = tblCitas.idDoctor) ON tblPacientes.IdPaciente = tblCitas.idPaciente", conexion)
        Me.daCitas.Fill(Me.dsHospital, "tblCitas")
        Me.daCitas.FillSchema(Me.dsHospital.Tables("tblCitas"), SchemaType.Source)
        Me.cmbCitas = New OleDbCommandBuilder(Me.daCitas)


        Me.daCupos = New OleDbDataAdapter("SELECT * FROM tblCupos", conexion)
        Me.daCupos.Fill(Me.dsHospital, "tblCupos")
        Me.daCupos.FillSchema(Me.dsHospital.Tables("tblCupos"), SchemaType.Source)
        Me.cmbCupos = New OleDbCommandBuilder(Me.daCupos)


        Me.daEspecialidades = New OleDbDataAdapter("SELECT * FROM tblEspecialidades", conexion)
        Me.daEspecialidades.Fill(Me.dsHospital, "tblEspecialidades")
        Me.daEspecialidades.FillSchema(Me.dsHospital.Tables("tblEspecialidades"), SchemaType.Source)
        Me.cmbEspecialidades = New OleDbCommandBuilder(Me.daEspecialidades)




        Me.bdpacientes.DataSource = Me.dsHospital.Tables("tblPacientes")
        Me.dgvPacientes.DataSource = Me.bdpacientes
        Me.dgvPacientes.ReadOnly = True
        Me.dgvPacientes.Columns("IdPaciente").HeaderText = "ID"
        Me.dgvPacientes.Columns("nombrePaciente").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Me.dgvPacientes.Columns("nombrePaciente").HeaderText = "Nombre de Paciente"
        Me.dgvPacientes.Columns("nombrePaciente").Width = 158
        Me.dgvPacientes.Columns("apellidoPaciente").HeaderText = "Apellido"
        Me.dgvPacientes.Columns("nombrePaciente").Width = 150
        Me.dgvPacientes.Columns("correoPaciente").HeaderText = "e-Mail"
        Me.dgvPacientes.Columns("correoPaciente").Width = 150

        Me.bddoctores.DataSource = Me.dsHospital.Tables("tblDoctores")
        Me.dgvdatosmedicos.DataSource = Me.bddoctores
        Me.dgvdatosmedicos.ReadOnly = True
        Me.dgvdatosmedicos.Columns("IdDoctor").HeaderText = "ID"
        Me.dgvdatosmedicos.Columns("nombreDoctor").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        Me.dgvdatosmedicos.Columns("nombreDoctor").HeaderText = "Nombre de Doctor"
        Me.dgvdatosmedicos.Columns("nombreDoctor").Width = 158
        Me.dgvdatosmedicos.Columns("apellidoDoctor").HeaderText = "Apellido"
        Me.dgvdatosmedicos.Columns("apellidoDoctor").Width = 150
        Me.dgvdatosmedicos.Columns("correoDoctor").HeaderText = "e-Mail"
        Me.dgvdatosmedicos.Columns("correoDoctor").Width = 150
        'Me.dgvdatosmedicos.Columns("tblEspecialidad").HeaderText = "Especialidades"

        Me.bdcitas.DataSource = Me.dsHospital.Tables("tblCitas")
        Me.dgvDatoscitas.DataSource = Me.bdcitas
        Me.dgvDatoscitas.ReadOnly = True
        Me.cbofiltrardoctores.DataSource = Me.dsHospital.Tables("tblEspecialidades")
        Me.cbofiltrardoctores.DisplayMember = "Especialidad"





    End Sub

 

    

    Private Sub cbofiltrardoctores_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles cbofiltrardoctores.MouseClick
        Me.controlador = False
    End Sub

    Private Sub cbofiltrardoctores_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbofiltrardoctores.SelectedIndexChanged
     
        If Me.controlador = False Then
            If Me.cbofiltrardoctores.SelectedIndex Then
                Dim n As Integer
                n = Me.cbofiltrardoctores.SelectedIndex + 1

                Me.dsHospital.Tables("tblDoctores").DefaultView.RowFilter = _
           "tblDoctores.Especialidad= '" & n & "'"


            Else
                Dim n As Integer
                n = Me.cbofiltrardoctores.SelectedIndex + 1

                Me.dsHospital.Tables("tblDoctores").DefaultView.RowFilter = _
            "tblDoctores.Especialidad= '" & n & "'"


            End If
        End If
       

    End Sub

  

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged

        Me.dsHospital.Tables("tblCitas").DefaultView.RowFilter = _
       "Fecha= '" & Convert.ToDateTime(Me.DateTimePicker1.Text) & "'"

        Me.bdcitas.DataSource = Me.dsHospital.Tables("tblCitas")
        Me.dgvDatoscitas.DataSource = Me.bdcitas
        Me.dgvDatoscitas.ReadOnly = True
    End Sub

    Private Sub btGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btGuardar.Click

        Dim estado As String
        Dim MyDataSet As New DataSetHospital   'Conjunto de datos
        Dim MyDataTable As New DataSetHospital.tblPacientesDataTable  'EL dataTable del conjunto de datos
        Dim mi_rptSocios As New CrystalReport1 'Documento cristal reports
        'Dim miReporte As New Form7 'Formulario visor
        Dim filas As Integer = Me.dgvPacientes.Rows.Count
        Dim i As Integer = 0
        For i = 0 To filas - 2
            'Paso los datos al dataset el "DataGridViewTextBoxColumn" se encuentra dentro de
            ' la propiedad Columns(coleccion)>Dise�o>Name

            Me.dgvPacientes.Columns("nombrePaciente").HeaderText = "Nombre de Paciente"
            If Me.dgvPacientes.Rows(i).Cells("estado").Value = True Then
                estado = "Activo"
            Else
                estado = "Inactivo "
            End If
            MyDataTable.Rows.Add(Me.dgvPacientes.Rows(i).Cells("IdPaciente").Value _
            , Me.dgvPacientes.Rows(i).Cells("nombrePaciente").Value _
            , Me.dgvPacientes.Rows(i).Cells("apellidoPaciente").Value _
            , Me.dgvPacientes.Rows(i).Cells("correoPaciente").Value _
            , Me.dgvPacientes.Rows(i).Cells("Direccion").Value _
            , Me.dgvPacientes.Rows(i).Cells("Telefono").Value _
            , Me.dgvPacientes.Rows(i).Cells("tipoSangre").Value _
            , estado)


        Next (i)
        '"Cliente" es la tabla en el dataset
        MyDataSet.Tables("tblPacientes").Merge(MyDataTable)
        mi_rptSocios.SetDataSource(MyDataSet)
        My.Forms.fmrReporteCristal.CrystalReportViewer1.ReportSource = mi_rptSocios
        My.Forms.fmrReporteCristal.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click


        Dim estado As String
        Dim MyDataSet As New DataSetHospital   'Conjunto de datos
        Dim MyDataTable As New DataSetHospital.tblDoctoresDataTable   'EL dataTable del conjunto de datos
        Dim mi_rptSocios As New CrystalReport2  'Documento cristal reports
        'Dim miReporte As New Form7 'Formulario visor
        Dim filas As Integer = Me.dgvdatosmedicos.Rows.Count
        Dim i As Integer = 0
        For i = 0 To filas - 2
            'Paso los datos al dataset el "DataGridViewTextBoxColumn" se encuentra dentro de
            ' la propiedad Columns(coleccion)>Dise�o>Name

           


            If Me.dgvdatosmedicos.Rows(i).Cells("estado").Value = True Then
                estado = "Activo"
            Else
                estado = "Inactivo "
            End If
            MyDataTable.Rows.Add(Me.dgvdatosmedicos.Rows(i).Cells("IdDoctor").Value _
            , Me.dgvdatosmedicos.Rows(i).Cells("nombreDoctor").Value _
            , Me.dgvdatosmedicos.Rows(i).Cells("apellidoDoctor").Value _
            , Me.dgvdatosmedicos.Rows(i).Cells("correoDoctor").Value _
            , Me.dgvdatosmedicos.Rows(i).Cells("Direccion").Value _
            , Me.dgvdatosmedicos.Rows(i).Cells("Telefono").Value _
            , Me.dgvdatosmedicos.Rows(i).Cells("tblEspecialidades.Especialidad").Value _
            , estado)


        Next (i)
        '"Cliente" es la tabla en el dataset
        MyDataSet.Tables("tblDoctores").Merge(MyDataTable)
        mi_rptSocios.SetDataSource(MyDataSet)
        My.Forms.fmrReporteMedico.CrystalReportViewer1.ReportSource = mi_rptSocios
        My.Forms.fmrReporteMedico.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim MyDataSet As New DataSetHospital   'Conjunto de datos
        Dim MyDataTable As New DataSetHospital.tblCitasDataTable    'EL dataTable del conjunto de datos
        Dim mi_rptSocios As New CrystalReport3 'Documento cristal reports
        'Dim miReporte As New Form7 'Formulario visor
        Dim filas As Integer = Me.dgvDatoscitas.Rows.Count
        Dim i As Integer = 0
        For i = 0 To filas - 2
            'Paso los datos al dataset el "DataGridViewTextBoxColumn" se encuentra dentro de
            ' la propiedad Columns(coleccion)>Dise�o>Name




            MyDataTable.Rows.Add(Me.dgvDatoscitas.Rows(i).Cells("IdCitas").Value _
            , Me.dgvDatoscitas.Rows(i).Cells("nombreDoctor").Value _
            , Me.dgvDatoscitas.Rows(i).Cells("apellidoDoctor").Value _
            , Me.dgvDatoscitas.Rows(i).Cells("nombrePaciente").Value _
            , Me.dgvDatoscitas.Rows(i).Cells("apellidoPaciente").Value _
            , Me.dgvDatoscitas.Rows(i).Cells("Fecha").Value)
       


        Next (i)
        '"Cliente" es la tabla en el dataset
        MyDataSet.Tables("tblCitas").Merge(MyDataTable)
        mi_rptSocios.SetDataSource(MyDataSet)
        My.Forms.fmrReportesCitas.CrystalReportViewer1.ReportSource = mi_rptSocios
        My.Forms.fmrReportesCitas.Show()
    End Sub

End Class