Imports System.Data
Imports System.Data.OleDb
Public Class frmEditarMedico
    Friend dsHospital As DataSet

    Friend daDoctores As OleDbDataAdapter
    Friend cmbDoctores As OleDbCommandBuilder


    Friend daEspecialidades As OleDbDataAdapter
    Friend cmbEspecialidades As OleDbCommandBuilder

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
        frmAdministrador.Show()
    End Sub

    Private Sub frmEditarMedico_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.dsHospital = My.Forms.frmLogin.dsHospital

        Me.daDoctores = My.Forms.frmLogin.daDoctores
        Me.cmbDoctores = My.Forms.frmLogin.cmbDoctores

        Me.daEspecialidades = My.Forms.frmLogin.daEspecialidades
        Me.daEspecialidades = My.Forms.frmLogin.daEspecialidades

        Me.bdMedicos.DataSource = Me.dsHospital.Tables("tblDoctores")


        Me.tbnombreMedico.PromptChar = " "
        Me.tbapellidoMedico.PromptChar = " "
        Me.tbidMedico.PromptChar = " "
        Me.btnNuevaBusqueda.Enabled = False
  

    End Sub

    Private Sub tbnombreMedico_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbnombreMedico.MouseClick
        Me.tbnombreMedico.Select(0, 0)
    End Sub

    Private Sub tbapellidoMedico_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbapellidoMedico.MouseClick
        Me.tbapellidoMedico.Select(0, 0)

    End Sub

    Private Sub tbTelefonoMedico_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbTelefonoMedico.MouseClick
        Me.tbTelefonoMedico.Select(0, 0)
    End Sub


    Private Sub tbidMedico_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbidMedico.KeyPress
        If Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57 Then
        Else
            If Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = ChrW(0)
            End If
        End If
    End Sub
    Private Sub ManejadorRb(ByVal sender As Object, ByVal e As ConvertEventArgs)
        e.Value = Not e.Value
    End Sub

    Private Sub btnAgregarMedico_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarMedico.Click
        If Me.tbnombreMedico.Text.StartsWith(" ") Or Me.tbapellidoMedico.Text.StartsWith(" ") Then
            MessageBox.Show("Nombre y Apellido Son Requeridos", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Me.bdMedicos.EndEdit()
            If Me.dsHospital.HasChanges() Then
                Try
                    Me.daDoctores.Update(Me.dsHospital.Tables("tblDoctores"))
                    MsgBox("Modificaciones realizadas con exito")
                Catch ex As Exception
                    MsgBox("Error al guardar: " & ControlChars.NewLine & ex.Message)
                End Try

            End If
        End If
    End Sub

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.bdMedicos.CancelEdit()
    End Sub

    Private Sub tbidMedico_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.VaciarCampos()
    End Sub
    Private Sub VaciarCampos()
        Me.tbnombreMedico.Text = Nothing
        Me.tbnombreMedico.DataBindings.Clear()

        Me.tbapellidoMedico.Text = Nothing
        Me.tbapellidoMedico.DataBindings.Clear()

        Me.tbTelefonoMedico.Text = Nothing
        Me.tbTelefonoMedico.DataBindings.Clear()


        Me.tbDireccionMedico.Text = Nothing
        Me.tbDireccionMedico.DataBindings.Clear()


        Me.tbCorreo.Text = Nothing
        Me.tbCorreo.DataBindings.Clear()

        Me.cboEspecialidad.DataSource = Nothing
        Me.cboEspecialidad.DataBindings.Clear()



        Me.tbContrase�aMedico.Text = Nothing
        Me.tbContrase�aMedico.DataBindings.Clear()

        'Me.rbActivo.Text = Nothing
        Me.rbActivo.DataBindings.Clear()


        'Me.rbInactivo.Text = Nothing
        Me.rbInactivo.DataBindings.Clear()
    End Sub

    Private Sub tbidMedico_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbidMedico.MouseClick
        Me.tbidMedico.Select(0, 0)
    End Sub



    Private Sub tbTelefonoMedico_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbTelefonoMedico.KeyPress
        If Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57 Then
        Else
            If Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = ChrW(0)
            End If
        End If
    End Sub

    Private Sub tbnombreMedico_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbnombreMedico.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub

    Private Sub tbapellidoMedico_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbapellidoMedico.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub

    Private Sub frmEditarMedico_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        'Me.btnSalir.PerformClick()
    End Sub

    Private Sub btnNuevaBusqueda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNuevaBusqueda.Click
        Me.tbidMedico.ReadOnly = False
        Me.tbidMedico.Text = Nothing
        Me.btnBuscar.Enabled = True
        Me.VaciarCampos()
        Me.btnNuevaBusqueda.Enabled = False
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        If Me.tbidMedico.Text = "" Then
            MessageBox.Show("Ingrese un Criterio de Busqueda", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else
            Dim filasEncontradas As DataRow()
            Dim idDoctor As Integer = Convert.ToInt32(Me.tbidMedico.Text)

            filasEncontradas = Me.dsHospital.Tables("tblDoctores").Select( _
                "idDoctor = '" & idDoctor & "'")

            If filasEncontradas.Length > 0 Then
                Me.bdMedicos.Position = _
                    Me.dsHospital.Tables("tblDoctores").Rows.IndexOf(filasEncontradas(0))
                Me.tbnombreMedico.DataBindings.Add( _
              New Binding("Text", Me.bdMedicos, "nombreDoctor"))


                Me.tbCorreo.DataBindings.Add( _
                               New Binding("Text", Me.bdMedicos, "correoDoctor"))

                Me.tbapellidoMedico.DataBindings.Add( _
                  New Binding("Text", Me.bdMedicos, "apellidoDoctor"))

                Me.tbDireccionMedico.DataBindings.Add( _
                  New Binding("Text", Me.bdMedicos, "Direccion"))

                Me.tbTelefonoMedico.DataBindings.Add( _
                 New Binding("Text", Me.bdMedicos, "Telefono"))

                Me.cboEspecialidad.DataBindings.Add(New Binding("Text", Me.bdMedicos, "Especialidad"))
                Me.cboEspecialidad.DataSource = Me.dsHospital.Tables("tblEspecialidades")
                Me.cboEspecialidad.DisplayMember = "Especialidad"


                Dim bin As Binding = New Binding("Checked", Me.bdMedicos, "Estado")
                AddHandler bin.Format, AddressOf ManejadorRb
                AddHandler bin.Parse, AddressOf ManejadorRb
                Me.rbInactivo.DataBindings.Add(bin)

                Me.rbActivo.DataBindings.Add( _
                    New Binding("Checked", Me.bdMedicos, "Estado"))


                Me.tbContrase�aMedico.DataBindings.Add( _
                New Binding("Text", Me.bdMedicos, "Contrase�aIngreso"))


                Me.tbidMedico.ReadOnly = True
                Me.btnBuscar.Enabled = False
                Me.btnNuevaBusqueda.Enabled = True
            Else
                MessageBox.Show("Medico No Encontrado", "Error en la Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Error)

                Me.tbidMedico.Text = Nothing

            End If


            
        End If

    End Sub
End Class