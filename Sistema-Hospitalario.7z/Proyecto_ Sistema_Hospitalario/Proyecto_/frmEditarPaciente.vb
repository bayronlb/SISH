Imports System.Data
Imports System.Data.OleDb
Public Class frmEditarPaciente
    Friend dsHospital As DataSet
    Friend daPacientes As OleDbDataAdapter
    Friend cmbPacientes As OleDbCommandBuilder



   

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
        frmAdministrador.Show()

    End Sub

    Private Sub frmEditarPaciente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.dsHospital = My.Forms.frmLogin.dsHospital
        Me.daPacientes = My.Forms.frmLogin.daPacientes
        Me.cmbPacientes = My.Forms.frmLogin.cmbPacientes
        Me.tbnombrePaciente.PromptChar = " "
        Me.tbapellidoPaciente.PromptChar = " "


        Me.dsHospital = My.Forms.frmLogin.dsHospital
        Me.daPacientes = My.Forms.frmLogin.daPacientes

        Me.bdPacientes.DataSource = Me.dsHospital.Tables("tblPacientes")

        Me.tbnombrePaciente.DataBindings.Add( _
            New Binding("Text", Me.bdPacientes, "nombrePaciente"))
        Me.tbapellidoPaciente.DataBindings.Add( _
            New Binding("Text", Me.bdPacientes, "apellidoPaciente"))
        Me.tbdireccionPaciente.DataBindings.Add( _
            New Binding("Text", Me.bdPacientes, "Direccion"))
        Me.tbtelefonoPaciente.DataBindings.Add( _
            New Binding("Text", Me.bdPacientes, "Telefono"))
        Me.cboTipoSangre.DataBindings.Add(New Binding("Text", Me.bdPacientes, ("tipoSangre")))
        Me.cboTipoSangre.Items.Add("O-")
        Me.cboTipoSangre.Items.Add("O+")
        Me.cboTipoSangre.Items.Add("A-")
        Me.cboTipoSangre.Items.Add("A+")
        Me.cboTipoSangre.Items.Add("B-")
        Me.cboTipoSangre.Items.Add("B+-")
        Me.cboTipoSangre.Items.Add("AB-")
        Me.cboTipoSangre.Items.Add("AB+")

        Dim bin As Binding = New Binding("Checked", Me.bdPacientes, "Estado")
        AddHandler bin.Format, AddressOf ManejadorRb
        AddHandler bin.Parse, AddressOf ManejadorRb
        Me.rbInactivo.DataBindings.Add(bin)

        Me.rbActivo.DataBindings.Add( _
            New Binding("Checked", Me.bdPacientes, "Estado"))


    End Sub

    Private Sub tbnombrePaciente_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbnombrePaciente.MouseClick
        Me.tbnombrePaciente.Select(0, 0)
    End Sub

    Private Sub tbapellidoPaciente_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbapellidoPaciente.MouseClick
        Me.tbapellidoPaciente.Select(0, 0)
    End Sub

    Private Sub tbtelefonoPaciente_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbtelefonoPaciente.MouseClick
        Me.tbtelefonoPaciente.Select(0, 0)
    End Sub
    Private Sub ManejadorRb(ByVal sender As Object, ByVal e As ConvertEventArgs)
        e.Value = Not e.Value
    End Sub

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.bdPacientes.CancelEdit()
    End Sub

    Private Sub btnActualizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActualizar.Click
        Me.bdPacientes.EndEdit()
        If Me.dsHospital.HasChanges() Then
            Try
                Me.daPacientes.Update(Me.dsHospital.Tables("tblPacientes"))
                MsgBox("Modificaciones realizadas con exito")
            Catch ex As Exception
                MsgBox("Error al guardar: " & ControlChars.NewLine & ex.Message)
            End Try

        End If
    End Sub

    Private Sub tbtelefonoPaciente_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbtelefonoPaciente.KeyPress
        If Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57 Then
        Else
            If Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = ChrW(0)
            End If
        End If
    End Sub

    Private Sub tbnombrePaciente_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbnombrePaciente.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub

    Private Sub tbapellidoPaciente_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbapellidoPaciente.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub


End Class