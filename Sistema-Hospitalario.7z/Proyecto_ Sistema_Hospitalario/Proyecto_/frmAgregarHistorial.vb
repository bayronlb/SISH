Imports System.Data
Imports System.Data.OleDb

Public Class frmAgregarHistorial
    Public idpaciente As Integer
    Friend dsHospital As DataSet
    Friend daHistoriales As OleDbDataAdapter
    Friend cmbHistoriales As OleDbCommandBuilder


    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
        frmManejarHistorial.Show()

    End Sub

    Private Sub frmAgregarHistorial_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.dtpFecha.MinDate = Now
        Me.dsHospital = My.Forms.frmLogin.dsHospital
        Me.daHistoriales = My.Forms.frmLogin.daHistoriales
        Me.cmbHistoriales = My.Forms.frmLogin.cmbHistoriales


        Me.bdAgregarHistorial.DataSource = Me.dsHospital.Tables("tblHistoriales")
        'Me.lblPaciente.Text=

    End Sub

    Private Sub btnAgregarHist_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarHist.Click

        If Me.tbEnfermedad.Text = "" And Me.tbTratamiento.Text = "" Then
            MessageBox.Show("No Pueden Haber Campos VAcios", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

            Dim dr As DataRow = Me.dsHospital.Tables("tblHistoriales").NewRow()

            dr.Item("idPaciente") = Me.idpaciente
            dr.Item("Enfermedad") = Me.tbEnfermedad.Text
            dr.Item("Tratamiento") = Me.tbTratamiento.Text
            dr.Item("Fecha") = Me.dtpFecha.Text


            Me.dsHospital.Tables("tblHistoriales").Rows.Add(dr)



            If Me.dsHospital.HasChanges() Then
                Try
                    Me.daHistoriales.Update(Me.dsHospital.Tables("tblHistoriales"))
                    MsgBox("Historial Agregado")
                Catch ex As Exception
                    MsgBox("Error al guardar: " & ControlChars.NewLine & ex.Message)
                End Try

            End If
        End If
    End Sub
    Public Function obtneridpaciente(ByVal idp As Integer) As Integer
        Me.idpaciente = idp

    End Function






    Private Sub tbTratamiento_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbTratamiento.TextChanged

    End Sub

End Class