Imports System.Data
Imports System.Data.OleDb
Public Class frmAgregarMedico
    Friend dsHospital As DataSet

    Friend daDoctores As OleDbDataAdapter
    Friend cmbDoctores As OleDbCommandBuilder


    Friend daEspecialidades As OleDbDataAdapter
    Friend cmbEspecialidades As OleDbCommandBuilder


    Dim Especialidad As New frmAgregarEspecialidad

    Dim n As Boolean = False

    Private Sub frmAgregarMedico_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.dsHospital = My.Forms.frmLogin.dsHospital

        Me.daDoctores = My.Forms.frmLogin.daDoctores
        Me.cmbDoctores = My.Forms.frmLogin.cmbDoctores

        Me.daEspecialidades = My.Forms.frmLogin.daEspecialidades
        Me.daEspecialidades = My.Forms.frmLogin.daEspecialidades


        Me.tbnombreMedico.PromptChar = " "
        Me.tbapellidoMedico.PromptChar = " "

        Me.cboEspecialidad.DataSource = Me.dsHospital.Tables("tblEspecialidades")
        Me.cboEspecialidad.DisplayMember = ("Especialidad")
        Me.lblError.Visible = False

    End Sub

    Private Sub btnAgregarEspecialidad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarEspecialidad.Click
        'Me.Hide()
        My.Forms.frmAgregarEspecialidad.Show()

    End Sub

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.limpiar()

    End Sub

    Private Sub tbnombreMedico_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbnombreMedico.KeyPress

        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub

    Private Sub tbnombreMedico_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbnombreMedico.MouseClick
        Me.tbnombreMedico.Select(0, 0)
        Me.ErrorCamposVacios.Dispose()
        Me.lblError.Visible = False

    End Sub
    Private Sub tbapellidoMedico_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbapellidoMedico.MouseClick
        Me.tbapellidoMedico.Select(0, 0)
    End Sub

    Private Sub tbtelefonoMedico_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbtelefonoMedico.KeyPress
        If Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57 Then
        Else
            If Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = ChrW(0)
            End If
        End If
    End Sub

    Private Sub tbtelefonoMedico_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbtelefonoMedico.MouseClick
        Me.tbtelefonoMedico.Select(0, 0)
    End Sub

    Private Sub btnAgregarMedico_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarMedico.Click
        If Me.tbnombreMedico.Text = "" Or Me.tbapellidoMedico.Text = "" Then
            '.StartsWith(" ") Or Me.tbapellidoMedico.Text.StartsWith(" ") Then
            Me.ErrorCamposVacios.SetError(Me.tbnombreMedico, "Campos Requeridos")
            Me.lblError.Visible = True
        Else
            Dim dr As DataRow = Me.dsHospital.Tables("tblDoctores").NewRow()

            dr.Item("nombreDoctor") = Me.tbnombreMedico.Text
            dr.Item("apellidoDoctor") = Me.tbapellidoMedico.Text
            dr.Item("correoDoctor") = Me.txbCorreo.Text
            dr.Item("Direccion") = Me.tbdireccionMedico.Text
            dr.Item("Telefono") = Me.tbtelefonoMedico.Text
            dr.Item("Estado") = True
            dr.Item("Contrase�aIngreso") = " "
            dr.Item("Especialidad") = Me.cboEspecialidad.SelectedIndex + 1

            Me.dsHospital.Tables("tblDoctores").Rows.Add(dr)

            If Me.dsHospital.HasChanges() Then
                Try
                    Me.daDoctores.Update(Me.dsHospital.Tables("tblDoctores"))
                    MsgBox("Doctor Agregado Correctamente")
                Catch ex As Exception
                    MsgBox("Error al guardar: " & ControlChars.NewLine & ex.Message)
                End Try

            End If
            Me.limpiar()
        End If
        

    End Sub

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Close()
        frmAdministrador.Show()
    End Sub

    Public Sub limpiar()
        Me.tbnombreMedico.Text = Nothing
        Me.tbapellidoMedico.Text = Nothing
        Me.tbdireccionMedico.Text = Nothing
        Me.tbtelefonoMedico.Text = Nothing
        Me.txbCorreo.Text = Nothing
    End Sub

    Private Sub tbapellidoMedico_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbapellidoMedico.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub

    Private Sub txbCorreo_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txbCorreo.MouseClick
        Me.txbCorreo.Select(0, 0)
    End Sub
End Class