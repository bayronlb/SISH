Imports System.Data
Imports System.Data.OleDb
Public Class frmManejarPacientes
    Dim EditPac As New frmEditarPaciente
    Dim AddCita As New frmAgregarCitas
    Friend dsHospital As New DataSet
    Friend daPacientes As OleDbDataAdapter
    Friend cmbPacientes As OleDbCommandBuilder
    Public idpaciente As Integer

    Private Sub frmManejarPacientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.dsHospital = My.Forms.frmLogin.dsHospital
        Me.daPacientes = My.Forms.frmLogin.daPacientes
        Me.cmbPacientes = My.Forms.frmLogin.cmbPacientes
        Me.btnAgregarCita.Enabled = False
        Me.btnEditarPaciente.Enabled = False
    End Sub
    Private Sub btnEditarPaciente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditarPaciente.Click
        Me.Hide()
        EditPac.Show()
    End Sub

    Private Sub btnAgregarCita_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarCita.Click
        Me.dgvDatos.Focus()
        Dim fls As Integer = Convert.ToInt32(Me.dgvDatos.CurrentRow.Index)
        Me.idpaciente = Me.dgvDatos.Rows(fls).Cells(0).Value
        Me.AddCita.lblPaciente.Text = Me.dgvDatos.Rows(fls).Cells(1).Value
        Me.AddCita.obtneridpaciente(Me.idpaciente)
        Me.Hide()
        AddCita.ShowDialog()
    End Sub

    Private Sub MaskedTextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub


    Private Sub btnBuscarPaciente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscarPaciente.Click
        If Me.tbnombrePaciente.Text = "" Then
            MessageBox.Show("Ingrese un Criterio de Busqueda", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else

            Me.bnPacientes.DataSource = Me.dsHospital.Tables("tblPacientes")
            Dim filasEncontradas As DataRow()
            filasEncontradas = Me.dsHospital.Tables("tblPacientes").Select("nombrePaciente LIKE '%" & Me.tbnombrePaciente.Text & "%'")
            If filasEncontradas.Length > 0 Then
                Me.bnPacientes.Position = Me.dsHospital.Tables("tblPacientes").Rows.IndexOf(filasEncontradas(0))
                Me.dgvDatos.ReadOnly = True
                Me.dgvDatos.DataSource = Me.bnPacientes
                Me.dgvDatos.Columns("idPaciente").Visible = False
                Me.dgvDatos.Columns("nombrePaciente").HeaderText = "Nombre de Paciente"
                Me.dgvDatos.Columns("apellidoPaciente").HeaderText = "Apellido de Paciente"
                Me.dgvDatos.Columns("correoPaciente").HeaderText = "Correo de Paciente"
                Me.dgvDatos.Columns("tipoSangre").HeaderText = "Tipo de Sangre"
                Me.dgvDatos.Columns("Direccion").HeaderText = "Direccion"
                Me.dgvDatos.Columns("telefono").HeaderText = "N� Telefono"
                Me.dgvDatos.Columns("nombrePaciente").ReadOnly = True
                Me.dgvDatos.Columns("nombrePaciente").MinimumWidth = 300
                Me.btnAgregarCita.Enabled = True
                Me.btnEditarPaciente.Enabled = True
                Me.dgvDatos.ReadOnly = True
            Else
                MessageBox.Show("No se encontro paciente", "Mensaje")
                Me.tbnombrePaciente.Text = ""
                Me.dgvDatos.DataSource = Nothing
                Me.dgvDatos.ReadOnly = True
                Me.dgvDatos.Enabled = False

            End If
        End If
    End Sub

    Private Sub dgvDatos_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvDatos.CellContentClick
        Me.dgvDatos.Focus()
        Dim fls As Integer = Convert.ToInt32(Me.dgvDatos.CurrentRow.Index)
        Me.idpaciente = Me.dgvDatos.Rows(fls).Cells(1).Value
        Me.AddCita.lblPaciente.Text = Me.dgvDatos.Rows(fls).Cells(3).Value
    End Sub

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Close()
        My.Forms.frmAdministrador.Show()
    End Sub

    Private Sub tbnombrePaciente_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbnombrePaciente.MouseClick
    Me.tbnombrePaciente.Select(0, 0)
    End Sub
End Class