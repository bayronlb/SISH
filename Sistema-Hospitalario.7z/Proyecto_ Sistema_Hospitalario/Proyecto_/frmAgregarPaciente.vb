Imports System.Data
Imports System.Data.OleDb
Public Class frmAgregarPaciente
    Friend dsHospital As DataSet
    Friend daPacientes As OleDbDataAdapter
    Private cmbPacientes As OleDbCommandBuilder

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Close()
        frmAdministrador.Show()

    End Sub

    Private Sub frmAgregarPaciente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        Me.CargarDatos()
        Me.lblError.Visible = False
        Me.cbotipoSangre.SelectedIndex = 0

    End Sub

    Private Sub btnAgregarPaciente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarPaciente.Click
        If Me.tbnombrePaciente.Text = "" Or Me.tbapellidoPaciente.Text = "" Then

            Me.ErrorCamposVacios.SetError(Me.tbnombrePaciente, "Campos Requeridos")
            Me.lblError.Visible = True
        Else
            Dim dr As DataRow = Me.dsHospital.Tables("tblPacientes").NewRow()

            dr.Item("nombrePaciente") = Me.tbnombrePaciente.Text
            dr.Item("apellidoPaciente") = Me.tbapellidoPaciente.Text
            dr.Item("correoPaciente") = Me.txbCorreo.Text
            dr.Item("Direccion") = Me.tbdireccionPaciente.Text
            dr.Item("Telefono") = Me.tbTelefonoPaciente.Text
            dr.Item("Estado") = True
            dr.Item("tipoSangre") = Me.cbotipoSangre.SelectedItem

            Me.dsHospital.Tables("tblPacientes").Rows.Add(dr)



            If Me.dsHospital.HasChanges() Then
                Try
                    Me.daPacientes.Update(Me.dsHospital.Tables("tblPacientes"))
                    MsgBox("Paciente Agregado Correctamente")
                Catch ex As Exception
                    MsgBox("Error al guardar: " & ControlChars.NewLine & ex.Message)
                End Try

            End If
            Me.limpiarPacientes()

        End If
    End Sub


    Private Sub tbnombrePaciente_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbnombrePaciente.MouseClick
        Me.tbnombrePaciente.Select(0, 0)
        Me.ErrorCamposVacios.Dispose()
        Me.lblError.Visible = False
    End Sub

    Private Sub tbapellidoPaciente_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbapellidoPaciente.MouseClick
        Me.tbapellidoPaciente.Select(0, 0)
    End Sub

    Private Sub tbdireccionPaciente_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbdireccionPaciente.TextChanged

    End Sub

    Private Sub tbTelefonoPaciente_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbTelefonoPaciente.MouseClick
        Me.tbTelefonoPaciente.Select(0, 0)
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        Me.limpiarPacientes()



    End Sub
    Public Sub CargarDatos()
        Me.dsHospital = My.Forms.frmLogin.dsHospital
        Me.daPacientes = My.Forms.frmLogin.daPacientes
        Me.cmbPacientes = My.Forms.frmLogin.cmbPacientes
        Me.tbnombrePaciente.PromptChar = " "
        Me.tbapellidoPaciente.PromptChar = " "
    End Sub


    Public Sub limpiarPacientes()
        Me.tbnombrePaciente.Text = Nothing
        Me.tbapellidoPaciente.Text = Nothing
        Me.tbdireccionPaciente.Text = Nothing
        Me.tbTelefonoPaciente.Text = Nothing
        Me.txbCorreo.Text = Nothing
        Me.cbotipoSangre.SelectedIndex = 0
    End Sub

    Private Sub tbTelefonoPaciente_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbTelefonoPaciente.KeyPress
        If Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57 Then
        Else
            If Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = ChrW(0)
            End If
        End If
    End Sub

    Private Sub tbnombrePaciente_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbnombrePaciente.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub

    Private Sub tbapellidoPaciente_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbapellidoPaciente.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub
End Class