<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAgregarEspecialidad
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Label1 = New System.Windows.Forms.Label
        Me.tbEspecialidades = New System.Windows.Forms.MaskedTextBox
        Me.btnAgregarEspecialidad = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.ErrorCamposVacios = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.lblError = New System.Windows.Forms.Label
        CType(Me.ErrorCamposVacios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(59, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nombre de la Nueva Especialidad"
        '
        'tbEspecialidades
        '
        Me.tbEspecialidades.Location = New System.Drawing.Point(62, 89)
        Me.tbEspecialidades.Mask = "??????????????????????????????????????????"
        Me.tbEspecialidades.Name = "tbEspecialidades"
        Me.tbEspecialidades.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbEspecialidades.Size = New System.Drawing.Size(165, 20)
        Me.tbEspecialidades.TabIndex = 1
        '
        'btnAgregarEspecialidad
        '
        Me.btnAgregarEspecialidad.Location = New System.Drawing.Point(51, 163)
        Me.btnAgregarEspecialidad.Name = "btnAgregarEspecialidad"
        Me.btnAgregarEspecialidad.Size = New System.Drawing.Size(75, 23)
        Me.btnAgregarEspecialidad.TabIndex = 2
        Me.btnAgregarEspecialidad.Text = "Agregar"
        Me.btnAgregarEspecialidad.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Location = New System.Drawing.Point(161, 163)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelar.TabIndex = 3
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'ErrorCamposVacios
        '
        Me.ErrorCamposVacios.ContainerControl = Me
        '
        'lblError
        '
        Me.lblError.AutoSize = True
        Me.lblError.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblError.ForeColor = System.Drawing.Color.Tomato
        Me.lblError.Location = New System.Drawing.Point(59, 112)
        Me.lblError.Name = "lblError"
        Me.lblError.Size = New System.Drawing.Size(169, 15)
        Me.lblError.TabIndex = 17
        Me.lblError.Text = "Agrege Una Especialidad"
        '
        'frmAgregarEspecialidad
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 241)
        Me.Controls.Add(Me.lblError)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnAgregarEspecialidad)
        Me.Controls.Add(Me.tbEspecialidades)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmAgregarEspecialidad"
        Me.Text = "Agregar Especialidad"
        CType(Me.ErrorCamposVacios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbEspecialidades As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btnAgregarEspecialidad As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents ErrorCamposVacios As System.Windows.Forms.ErrorProvider
    Friend WithEvents lblError As System.Windows.Forms.Label
End Class
