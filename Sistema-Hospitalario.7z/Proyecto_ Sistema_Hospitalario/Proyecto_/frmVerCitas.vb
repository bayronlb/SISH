Imports System.Data
Imports System.Data.OleDb

Public Class frmVerCitas
    Friend dsHospital As New DataSet
    Friend daCitas As OleDbDataAdapter
    Friend cmbCitas As OleDbCommandBuilder
    Dim idUsuario As Integer
    Private cadenaConexion As String = _
              "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & _
                  Application.StartupPath & "\bdHospital.accdb'"
    Private conexion As OleDbConnection



    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
        frmMedico.Show()

    End Sub

    Private Sub frmVerCitas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.idUsuario = My.Forms.frmLogin.idUsuario
        Me.dsHospital = New DataSet("dsHospital")
        Me.conexion = New OleDbConnection(cadenaConexion)


        Me.daCitas = New OleDbDataAdapter("SELECT tblCitas.IdCitas, tblCitas.idPaciente, tblCitas.idDoctor, tblPacientes.nombrePaciente,tblCitas.Fecha FROM tblPacientes INNER JOIN tblCitas ON tblPacientes.IdPaciente = tblCitas.idPaciente", conexion)

        Me.daCitas.Fill(Me.dsHospital, "tblCitas")

        Me.daCitas.FillSchema(Me.dsHospital.Tables("tblCitas"), SchemaType.Source)
        Me.cmbCitas = New OleDbCommandBuilder(Me.daCitas)



        Me.dsHospital.Tables("tblCitas").DefaultView.RowFilter = _
        "idDoctor= '" & Me.idUsuario & "'"

        Me.bdcitas.DataSource = Me.dsHospital.Tables("tblCitas")

        Me.dgvDatosCitas.DataSource = Me.bdcitas
        Me.dgvDatosCitas.Columns("Idcitas").Visible = False
        Me.dgvDatosCitas.Columns("idDoctor").Visible = False
        Me.dgvDatosCitas.Columns("nombrePaciente").HeaderText = "Nombre de Paciente"
        Me.dgvDatosCitas.Columns("Fecha").HeaderText = "Fecha"
        Me.dgvDatosCitas.Enabled = False
    End Sub

    Private Sub dgvDatosCitas_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvDatosCitas.CellContentClick

    End Sub
End Class