Public Class frmMedico
    Dim VerCitas As New frmVerCitas
    Dim VerPacientes As New frmManejarHistorial

    Private Sub btnVerCitas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerCitas.Click
        Me.Hide()
        VerCitas.ShowDialog()
    End Sub

    Private Sub btnVerHistoria_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerHistoria.Click
        Me.Hide()
        VerPacientes.ShowDialog()
    End Sub

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Hide()
        My.Forms.frmLogin.Show()
    End Sub

    Private Sub lblDoctor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblDoctor.Click



    End Sub
End Class