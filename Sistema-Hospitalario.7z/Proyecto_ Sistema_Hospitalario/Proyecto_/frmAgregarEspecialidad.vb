Imports System.Data
Imports System.Data.OleDb
Public Class frmAgregarEspecialidad
    Friend dsHospital As New DataSet
    Friend daEspecialidades As OleDbDataAdapter
    Friend cmbEspecialidades As OleDbCommandBuilder




    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Close()
        'frmAgregarMedico.Show()
    End Sub

    Private Sub frmAgregarEspecialidad_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.tbEspecialidades.PromptChar = " "
        Me.lblError.Visible = False
        Me.dsHospital = My.Forms.frmLogin.dsHospital
        Me.daEspecialidades = My.Forms.frmLogin.daEspecialidades
        Me.daEspecialidades = My.Forms.frmLogin.daEspecialidades


    End Sub

    Private Sub tbEspecialidades_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbEspecialidades.MouseClick
        Me.tbEspecialidades.Select(0, 0)
        Me.ErrorCamposVacios.Dispose()
        Me.lblError.Visible = False
    End Sub

    Private Sub btnAgregarEspecialidad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarEspecialidad.Click
        If Me.tbEspecialidades.Text = "" Then
            Me.lblError.Visible = True
            Me.ErrorCamposVacios.SetError(Me.lblError, "Campos Vacios")
            ''MessageBox("asdf", "Some title", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else
            Dim dr As DataRow = Me.dsHospital.Tables("tblEspecialidades").NewRow()

            dr.Item("Especialidad") = Me.tbEspecialidades.Text
            Me.dsHospital.Tables("tblEspecialidades").Rows.Add(dr)
            If Me.dsHospital.HasChanges() Then
                Try
                    Me.daEspecialidades.Update(Me.dsHospital.Tables("tblEspecialidades"))
                    MsgBox("Especialidad agregada con exito ")
                    Me.Close()
                Catch ex As Exception
                    MsgBox("Error al guardar: " & ControlChars.NewLine & ex.Message)
                End Try

            End If

        End If

    End Sub
End Class