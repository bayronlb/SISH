<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAgregarMedico
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.tbdireccionMedico = New System.Windows.Forms.TextBox
        Me.tbapellidoMedico = New System.Windows.Forms.MaskedTextBox
        Me.tbnombreMedico = New System.Windows.Forms.MaskedTextBox
        Me.tbtelefonoMedico = New System.Windows.Forms.MaskedTextBox
        Me.btnSalir = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.btnAgregarMedico = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cboEspecialidad = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnAgregarEspecialidad = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txbCorreo = New System.Windows.Forms.MaskedTextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.ErrorCamposVacios = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.lblError = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        CType(Me.ErrorCamposVacios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tbdireccionMedico
        '
        Me.tbdireccionMedico.Location = New System.Drawing.Point(94, 173)
        Me.tbdireccionMedico.Multiline = True
        Me.tbdireccionMedico.Name = "tbdireccionMedico"
        Me.tbdireccionMedico.Size = New System.Drawing.Size(153, 66)
        Me.tbdireccionMedico.TabIndex = 4
        '
        'tbapellidoMedico
        '
        Me.tbapellidoMedico.Location = New System.Drawing.Point(94, 89)
        Me.tbapellidoMedico.Mask = "????????????????????"
        Me.tbapellidoMedico.Name = "tbapellidoMedico"
        Me.tbapellidoMedico.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbapellidoMedico.Size = New System.Drawing.Size(153, 20)
        Me.tbapellidoMedico.TabIndex = 2
        '
        'tbnombreMedico
        '
        Me.tbnombreMedico.Location = New System.Drawing.Point(94, 42)
        Me.tbnombreMedico.Mask = "????????????????????"
        Me.tbnombreMedico.Name = "tbnombreMedico"
        Me.tbnombreMedico.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbnombreMedico.Size = New System.Drawing.Size(153, 20)
        Me.tbnombreMedico.TabIndex = 1
        '
        'tbtelefonoMedico
        '
        Me.tbtelefonoMedico.Location = New System.Drawing.Point(94, 245)
        Me.tbtelefonoMedico.Mask = "9999-99-99"
        Me.tbtelefonoMedico.Name = "tbtelefonoMedico"
        Me.tbtelefonoMedico.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbtelefonoMedico.Size = New System.Drawing.Size(153, 20)
        Me.tbtelefonoMedico.TabIndex = 5
        '
        'btnSalir
        '
        Me.btnSalir.Location = New System.Drawing.Point(225, 368)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(75, 23)
        Me.btnSalir.TabIndex = 10
        Me.btnSalir.Text = "Limpiar"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Location = New System.Drawing.Point(127, 368)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelar.TabIndex = 9
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'btnAgregarMedico
        '
        Me.btnAgregarMedico.Location = New System.Drawing.Point(36, 368)
        Me.btnAgregarMedico.Name = "btnAgregarMedico"
        Me.btnAgregarMedico.Size = New System.Drawing.Size(75, 23)
        Me.btnAgregarMedico.TabIndex = 8
        Me.btnAgregarMedico.Text = "Agregar"
        Me.btnAgregarMedico.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 245)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Telefono"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Direccion"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Apellido"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nombre"
        '
        'cboEspecialidad
        '
        Me.cboEspecialidad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEspecialidad.FormattingEnabled = True
        Me.cboEspecialidad.Location = New System.Drawing.Point(126, 282)
        Me.cboEspecialidad.Name = "cboEspecialidad"
        Me.cboEspecialidad.Size = New System.Drawing.Size(121, 21)
        Me.cboEspecialidad.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 290)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Especialidad"
        '
        'btnAgregarEspecialidad
        '
        Me.btnAgregarEspecialidad.Location = New System.Drawing.Point(45, 19)
        Me.btnAgregarEspecialidad.Name = "btnAgregarEspecialidad"
        Me.btnAgregarEspecialidad.Size = New System.Drawing.Size(33, 23)
        Me.btnAgregarEspecialidad.TabIndex = 7
        Me.btnAgregarEspecialidad.Text = "+"
        Me.btnAgregarEspecialidad.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnAgregarEspecialidad)
        Me.GroupBox1.Location = New System.Drawing.Point(295, 270)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(121, 42)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Agregar Especialidad"
        '
        'txbCorreo
        '
        Me.txbCorreo.Location = New System.Drawing.Point(94, 132)
        Me.txbCorreo.Name = "txbCorreo"
        Me.txbCorreo.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.txbCorreo.Size = New System.Drawing.Size(153, 20)
        Me.txbCorreo.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(23, 139)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Correo"
        '
        'ErrorCamposVacios
        '
        Me.ErrorCamposVacios.ContainerControl = Me
        '
        'lblError
        '
        Me.lblError.AutoSize = True
        Me.lblError.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblError.ForeColor = System.Drawing.Color.Tomato
        Me.lblError.Location = New System.Drawing.Point(42, 339)
        Me.lblError.Name = "lblError"
        Me.lblError.Size = New System.Drawing.Size(226, 15)
        Me.lblError.TabIndex = 16
        Me.lblError.Text = "Nombre y Apellido Son Requeidos"
        '
        'frmAgregarMedico
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(454, 425)
        Me.Controls.Add(Me.lblError)
        Me.Controls.Add(Me.txbCorreo)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cboEspecialidad)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbdireccionMedico)
        Me.Controls.Add(Me.tbapellidoMedico)
        Me.Controls.Add(Me.tbnombreMedico)
        Me.Controls.Add(Me.tbtelefonoMedico)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnAgregarMedico)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmAgregarMedico"
        Me.Text = "frmAgregarMedico"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.ErrorCamposVacios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tbdireccionMedico As System.Windows.Forms.TextBox
    Friend WithEvents tbapellidoMedico As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbnombreMedico As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbtelefonoMedico As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents btnAgregarMedico As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboEspecialidad As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnAgregarEspecialidad As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txbCorreo As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents ErrorCamposVacios As System.Windows.Forms.ErrorProvider
    Friend WithEvents lblError As System.Windows.Forms.Label
End Class
