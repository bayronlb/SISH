Public Class frmAdministrador
    Dim ManPacientes As New frmManejarPacientes
    Dim AgregPac As New frmAgregarPaciente
    Dim EditMedic As New frmEditarMedico
    Dim AgregMedic As New frmAgregarMedico
    Dim Reportes As New frmReportes
    Private Sub btnAgregarPaciente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarPaciente.Click
        Me.Hide()
        AgregPac.ShowDialog()
    End Sub

    Private Sub btnEditarPaciente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditarPaciente.Click
        Me.Hide()
        ManPacientes.ShowDialog()

    End Sub

    Private Sub btnAgregarMedico_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarMedico.Click
        Me.Hide()
        AgregMedic.ShowDialog()
    End Sub

    Private Sub btnEditarMedicos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditarMedicos.Click
        Me.Hide()
        EditMedic.ShowDialog()
    End Sub

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
        frmLogin.Show()
    End Sub

    Private Sub btnInformes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInformes.Click
        Me.Hide()
        Reportes.ShowDialog()
    End Sub

  
End Class