<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAgregarPaciente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnAgregarPaciente = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.btnLimpiar = New System.Windows.Forms.Button
        Me.tbTelefonoPaciente = New System.Windows.Forms.MaskedTextBox
        Me.tbnombrePaciente = New System.Windows.Forms.MaskedTextBox
        Me.tbapellidoPaciente = New System.Windows.Forms.MaskedTextBox
        Me.tbdireccionPaciente = New System.Windows.Forms.TextBox
        Me.cbotipoSangre = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txbCorreo = New System.Windows.Forms.MaskedTextBox
        Me.ErrorCamposVacios = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.lblError = New System.Windows.Forms.Label
        CType(Me.ErrorCamposVacios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(50, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nombre"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(50, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Apellido"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(50, 158)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Direccion"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(50, 230)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Telefono"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(50, 279)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Tipo de Sangre"
        '
        'btnAgregarPaciente
        '
        Me.btnAgregarPaciente.Location = New System.Drawing.Point(68, 377)
        Me.btnAgregarPaciente.Name = "btnAgregarPaciente"
        Me.btnAgregarPaciente.Size = New System.Drawing.Size(75, 23)
        Me.btnAgregarPaciente.TabIndex = 7
        Me.btnAgregarPaciente.Text = "Agregar"
        Me.btnAgregarPaciente.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Location = New System.Drawing.Point(159, 377)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelar.TabIndex = 8
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'btnLimpiar
        '
        Me.btnLimpiar.Location = New System.Drawing.Point(257, 377)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(75, 23)
        Me.btnLimpiar.TabIndex = 9
        Me.btnLimpiar.Text = "Limpiar"
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'tbTelefonoPaciente
        '
        Me.tbTelefonoPaciente.Location = New System.Drawing.Point(121, 230)
        Me.tbTelefonoPaciente.Mask = "9999-99-99"
        Me.tbTelefonoPaciente.Name = "tbTelefonoPaciente"
        Me.tbTelefonoPaciente.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbTelefonoPaciente.Size = New System.Drawing.Size(153, 20)
        Me.tbTelefonoPaciente.TabIndex = 5
        '
        'tbnombrePaciente
        '
        Me.tbnombrePaciente.Location = New System.Drawing.Point(121, 26)
        Me.tbnombrePaciente.Mask = "???????????????????????????????????????????????"
        Me.tbnombrePaciente.Name = "tbnombrePaciente"
        Me.tbnombrePaciente.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbnombrePaciente.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.tbnombrePaciente.ShortcutsEnabled = False
        Me.tbnombrePaciente.Size = New System.Drawing.Size(153, 20)
        Me.tbnombrePaciente.TabIndex = 1
        '
        'tbapellidoPaciente
        '
        Me.tbapellidoPaciente.AllowPromptAsInput = False
        Me.tbapellidoPaciente.Location = New System.Drawing.Point(121, 73)
        Me.tbapellidoPaciente.Mask = "????????????????????????????????????????????????????????????"
        Me.tbapellidoPaciente.Name = "tbapellidoPaciente"
        Me.tbapellidoPaciente.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbapellidoPaciente.Size = New System.Drawing.Size(153, 20)
        Me.tbapellidoPaciente.TabIndex = 2
        '
        'tbdireccionPaciente
        '
        Me.tbdireccionPaciente.Location = New System.Drawing.Point(121, 158)
        Me.tbdireccionPaciente.Multiline = True
        Me.tbdireccionPaciente.Name = "tbdireccionPaciente"
        Me.tbdireccionPaciente.Size = New System.Drawing.Size(153, 66)
        Me.tbdireccionPaciente.TabIndex = 4
        '
        'cbotipoSangre
        '
        Me.cbotipoSangre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbotipoSangre.FormattingEnabled = True
        Me.cbotipoSangre.Items.AddRange(New Object() {"O-", "O+ " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9), "A− " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9), "A+ " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9), "B− " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9), "B+ " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9), "AB− " & Global.Microsoft.VisualBasic.ChrW(9), "AB+"})
        Me.cbotipoSangre.Location = New System.Drawing.Point(153, 271)
        Me.cbotipoSangre.Name = "cbotipoSangre"
        Me.cbotipoSangre.Size = New System.Drawing.Size(121, 21)
        Me.cbotipoSangre.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(50, 124)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Correo"
        '
        'txbCorreo
        '
        Me.txbCorreo.AllowPromptAsInput = False
        Me.txbCorreo.Location = New System.Drawing.Point(121, 117)
        Me.txbCorreo.Name = "txbCorreo"
        Me.txbCorreo.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.txbCorreo.Size = New System.Drawing.Size(153, 20)
        Me.txbCorreo.TabIndex = 3
        '
        'ErrorCamposVacios
        '
        Me.ErrorCamposVacios.ContainerControl = Me
        '
        'lblError
        '
        Me.lblError.AutoSize = True
        Me.lblError.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblError.ForeColor = System.Drawing.Color.Tomato
        Me.lblError.Location = New System.Drawing.Point(65, 315)
        Me.lblError.Name = "lblError"
        Me.lblError.Size = New System.Drawing.Size(226, 15)
        Me.lblError.TabIndex = 17
        Me.lblError.Text = "Nombre y Apellido Son Requeidos"
        '
        'frmAgregarPaciente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(388, 430)
        Me.Controls.Add(Me.lblError)
        Me.Controls.Add(Me.txbCorreo)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cbotipoSangre)
        Me.Controls.Add(Me.tbdireccionPaciente)
        Me.Controls.Add(Me.tbapellidoPaciente)
        Me.Controls.Add(Me.tbnombrePaciente)
        Me.Controls.Add(Me.tbTelefonoPaciente)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnAgregarPaciente)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmAgregarPaciente"
        Me.Text = "Agregar Paciente"
        CType(Me.ErrorCamposVacios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnAgregarPaciente As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents btnLimpiar As System.Windows.Forms.Button
    Friend WithEvents tbTelefonoPaciente As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbnombrePaciente As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbapellidoPaciente As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbdireccionPaciente As System.Windows.Forms.TextBox
    Friend WithEvents cbotipoSangre As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txbCorreo As System.Windows.Forms.MaskedTextBox
    Friend WithEvents ErrorCamposVacios As System.Windows.Forms.ErrorProvider
    Friend WithEvents lblError As System.Windows.Forms.Label
End Class
