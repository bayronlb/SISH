Imports System.Data
Imports System.Data.OleDb
Public Class frmAgregarCitas
    Friend dsHospital As New DataSet
    Friend daPacientes As OleDbDataAdapter
    Friend daCitas As OleDbDataAdapter
    Friend cmbPacientes As OleDbCommandBuilder
    Private cadenaConexion As String = _
               "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & _
                   Application.StartupPath & "\bdHospital.accdb'"
    Private conexion As OleDbConnection
    Dim fila As DataRow
    Dim datoscorrectos As Boolean = False
    Dim idDoctor As Integer
    Dim indiceEsp As Integer
    Dim numeroCupos As Integer
    Dim nombreEsp As String
    Dim busqueda As String
    Public idpaciente As Integer
    Dim FilasEncontradas As DataRow()

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Close()
        frmManejarPacientes.Show()
    End Sub

    Private Sub frmAgregarCitas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.conexion = New OleDbConnection(cadenaConexion)
        Me.dtpFechaConsulta.MinDate = Now
        Me.dsHospital = My.Forms.frmLogin.dsHospital
        Me.daPacientes = My.Forms.frmLogin.daPacientes
        Me.daCitas = My.Forms.frmLogin.daCitas
        Me.cmbPacientes = My.Forms.frmLogin.cmbPacientes
        Me.cmbArea.DataSource = Me.dsHospital.Tables("tblEspecialidades")
        Me.cmbArea.DisplayMember = "Especialidad"

        

    End Sub

    Private Sub cmbArea_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbArea.SelectedIndexChanged
        Me.dsHospital.Tables("tblDoctores").DefaultView.RowFilter = _
          "Especialidad= '" & Me.cmbArea.SelectedIndex + 1 & "'"
        Me.cmbDoctor.DataSource = Me.dsHospital.Tables("tblDoctores")
        Me.cmbDoctor.DisplayMember = "nombreDoctor"

        'indiceEsp = Me.cmbArea.SelectedIndex + 1
        'busqueda = "Especialidad = '" & indiceEsp & "'"
        'Me.FilasEncontradas = Me.dsHospital.Tables("tblDoctores").Select(Me.busqueda)
        'Me.bdCitas.DataSource = Me.FilasEncontradas

        'Me.cmbDoctor.DataSource = Me.bdCitas
        'Me.cmbDoctor.ValueMember = "nombreDoctor"
        'Me.cmbDoctor.DisplayMember = "nombreDoctor"


        ' Me.cmbDoctor.Items.Clear()
        '.cmbDoctor.Text = ""
        'For i As Integer = 0 To Me.dsHospital.Tables("tblDoctores").Rows.Count - 1
        'fila = Me.dsHospital.Tables("tblDoctores").Rows(i)
        ' If fila("Especialidad").Equals(Me.indiceEsp) Then
        ' Me.cmbDoctor.Items.Add(fila("nombreDoctor"))
        'End If

        ' Next
        ' Me.cmbDoctor.SelectedIndex = 0
    End Sub

    Private Sub btnAgregarCita_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarCita.Click
        Dim Fecha As Date
        fecha = Convert.ToDateTime(Me.dtpFechaConsulta.Text)

        Dim conexion As New OleDbConnection(cadenaConexion)
        Dim conexionu As New OleDbConnection(cadenaConexion)
        Dim SQL As String = "SELECT * FROM tblCupos WHERE IdDoctor =@idDoctor  AND FechaCita = @FechaCita"

        Dim lectorDatos As OleDbDataReader
        Dim comandoSQL As New OleDbCommand(SQL, conexion)
        comandoSQL.Parameters.AddWithValue("@idDoctor", Me.idDoctor)
        comandoSQL.Parameters.AddWithValue("@FechaCita", fecha)

        conexion.Open()

        lectorDatos = comandoSQL.ExecuteReader()


        If lectorDatos.Read() Then


            numeroCupos = (lectorDatos.GetInt32(1))

            If numeroCupos <> 0 Then
                Try
                    conexionu.Open()
                    numeroCupos = numeroCupos - 1
                    Dim Sqlupdate As String = "UPDATE tblCupos  SET  CuposDisp = @CuposDisp  WHERE IdDoctor = " & Me.idDoctor & " AND FechaCita = " & "#" & Convert.ToDateTime(Me.dtpFechaConsulta.Text) & "#" & " "
                    Dim cmdupdate As New OleDb.OleDbCommand(Sqlupdate, conexionu)
                    cmdupdate.Parameters.Add(New OleDbParameter("@cuposDisp", OleDbType.BigInt))
                    cmdupdate.Parameters("@cuposDisp").Value = numeroCupos

                    Dim iResultado As Integer

                    iResultado = cmdupdate.ExecuteNonQuery
                    conexionu.Close()

                Catch ex As Exception
                    MsgBox("no se pudo restar cupos")
                End Try

            Else
                MsgBox("Este doctor ya tiene los cupos llenos para esta fecha")

                lectorDatos.Close()
            End If
           
          


        Else
            Try
                Dim SqlInsertar As String = " INSERT INTO tblCupos (IdDoctor, CuposDisp, FechaCita) VALUES (@idDoctor, @CuposDisp, @FechaCita)"
                Dim cmdInsertar As New OleDb.OleDbCommand(SqlInsertar, conexion)
                cmdInsertar.Parameters.Add(New OleDbParameter("@idDoctor", Me.idDoctor))
                cmdInsertar.Parameters.Add(New OleDbParameter("@CuposDisp", 9))
                cmdInsertar.Parameters.Add(New OleDbParameter("@FechaCita", Convert.ToDateTime(Me.dtpFechaConsulta.Text)))

                Dim iResultado As Integer

                iResultado = cmdInsertar.ExecuteNonQuery
                conexion.Close()
                numeroCupos = 1
            Catch ex As Exception
                MsgBox("no se pudo insertar nuevos  cupos ")
            End Try


        End If



        If numeroCupos <> 0 Then
            Dim dr As DataRow = Me.dsHospital.Tables("tblCitas").NewRow()
            dr.Item("idPaciente") = Me.idpaciente
            dr.Item("idDoctor") = Me.idDoctor
            dr.Item("Fecha") = Me.dtpFechaConsulta.Text
            Me.dsHospital.Tables("tblCitas").Rows.Add(dr)

            If Me.dsHospital.HasChanges() Then
                Try
                    Me.daCitas.Update(Me.dsHospital.Tables("tblCitas"))
                    MsgBox("Cita Agregada")
                Catch ex As Exception
                    MsgBox("Error al guardar: " & ControlChars.NewLine & ex.Message)
                End Try
            End If

            Me.Close()
            My.Forms.frmAdministrador.Show()

           
        End If
       
    End Sub
    Public Function obtneridpaciente(ByVal idp As Integer) As Integer
        Me.idpaciente = idp

    End Function

    Private Sub cmbDoctor_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbDoctor.SelectedIndexChanged
        Dim dato As DataRowView
        dato = Me.cmbDoctor.SelectedItem
        Me.idDoctor = Convert.ToInt32(dato.Item("idDoctor"))





    End Sub
End Class


