<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManejarPacientes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnBuscarPaciente = New System.Windows.Forms.Button
        Me.dgvDatos = New System.Windows.Forms.DataGridView
        Me.btnEditarPaciente = New System.Windows.Forms.Button
        Me.btnAgregarCita = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.bnPacientes = New System.Windows.Forms.BindingSource(Me.components)
        Me.tbnombrePaciente = New System.Windows.Forms.MaskedTextBox
        CType(Me.dgvDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bnPacientes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(55, 63)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Nombre Paciente"
        '
        'btnBuscarPaciente
        '
        Me.btnBuscarPaciente.Location = New System.Drawing.Point(388, 60)
        Me.btnBuscarPaciente.Name = "btnBuscarPaciente"
        Me.btnBuscarPaciente.Size = New System.Drawing.Size(75, 23)
        Me.btnBuscarPaciente.TabIndex = 2
        Me.btnBuscarPaciente.Text = "Buscar"
        Me.btnBuscarPaciente.UseVisualStyleBackColor = True
        '
        'dgvDatos
        '
        Me.dgvDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDatos.Location = New System.Drawing.Point(29, 112)
        Me.dgvDatos.Name = "dgvDatos"
        Me.dgvDatos.Size = New System.Drawing.Size(819, 246)
        Me.dgvDatos.TabIndex = 7
        '
        'btnEditarPaciente
        '
        Me.btnEditarPaciente.Location = New System.Drawing.Point(58, 393)
        Me.btnEditarPaciente.Name = "btnEditarPaciente"
        Me.btnEditarPaciente.Size = New System.Drawing.Size(134, 45)
        Me.btnEditarPaciente.TabIndex = 3
        Me.btnEditarPaciente.Text = "Editar Datos Paciente"
        Me.btnEditarPaciente.UseVisualStyleBackColor = True
        '
        'btnAgregarCita
        '
        Me.btnAgregarCita.Location = New System.Drawing.Point(368, 393)
        Me.btnAgregarCita.Name = "btnAgregarCita"
        Me.btnAgregarCita.Size = New System.Drawing.Size(134, 45)
        Me.btnAgregarCita.TabIndex = 4
        Me.btnAgregarCita.Text = "Agregar Citas"
        Me.btnAgregarCita.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Location = New System.Drawing.Point(676, 393)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(134, 45)
        Me.btnCancelar.TabIndex = 5
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'tbnombrePaciente
        '
        Me.tbnombrePaciente.Location = New System.Drawing.Point(162, 63)
        Me.tbnombrePaciente.Mask = "???????????????????????????????????????????????????????????????"
        Me.tbnombrePaciente.Name = "tbnombrePaciente"
        Me.tbnombrePaciente.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbnombrePaciente.Size = New System.Drawing.Size(184, 20)
        Me.tbnombrePaciente.TabIndex = 1
        '
        'frmManejarPacientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(877, 476)
        Me.Controls.Add(Me.tbnombrePaciente)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnAgregarCita)
        Me.Controls.Add(Me.btnEditarPaciente)
        Me.Controls.Add(Me.dgvDatos)
        Me.Controls.Add(Me.btnBuscarPaciente)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmManejarPacientes"
        Me.Text = "frmManejarPacientes"
        CType(Me.dgvDatos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bnPacientes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnBuscarPaciente As System.Windows.Forms.Button
    Friend WithEvents dgvDatos As System.Windows.Forms.DataGridView
    Friend WithEvents btnEditarPaciente As System.Windows.Forms.Button
    Friend WithEvents btnAgregarCita As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents bnPacientes As System.Windows.Forms.BindingSource
    Friend WithEvents tbnombrePaciente As System.Windows.Forms.MaskedTextBox
End Class
