<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAgregarCitas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblPaciente = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.cmbArea = New System.Windows.Forms.ComboBox
        Me.cmbDoctor = New System.Windows.Forms.ComboBox
        Me.Doctor = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.dtpFechaConsulta = New System.Windows.Forms.DateTimePicker
        Me.btnAgregarCita = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.bdCitas = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.bdCitas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(72, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(254, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Agregar Citas Para Paciente:"
        '
        'lblPaciente
        '
        Me.lblPaciente.AutoSize = True
        Me.lblPaciente.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaciente.Location = New System.Drawing.Point(332, 51)
        Me.lblPaciente.Name = "lblPaciente"
        Me.lblPaciente.Size = New System.Drawing.Size(82, 24)
        Me.lblPaciente.TabIndex = 1
        Me.lblPaciente.Text = "Paciente"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(88, 134)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Area de Consulta"
        '
        'cmbArea
        '
        Me.cmbArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbArea.FormattingEnabled = True
        Me.cmbArea.Location = New System.Drawing.Point(203, 134)
        Me.cmbArea.Name = "cmbArea"
        Me.cmbArea.Size = New System.Drawing.Size(121, 21)
        Me.cmbArea.TabIndex = 3
        '
        'cmbDoctor
        '
        Me.cmbDoctor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbDoctor.FormattingEnabled = True
        Me.cmbDoctor.Location = New System.Drawing.Point(205, 204)
        Me.cmbDoctor.Name = "cmbDoctor"
        Me.cmbDoctor.Size = New System.Drawing.Size(121, 21)
        Me.cmbDoctor.TabIndex = 5
        '
        'Doctor
        '
        Me.Doctor.AutoSize = True
        Me.Doctor.Location = New System.Drawing.Point(88, 204)
        Me.Doctor.Name = "Doctor"
        Me.Doctor.Size = New System.Drawing.Size(39, 13)
        Me.Doctor.TabIndex = 4
        Me.Doctor.Text = "Doctor"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(88, 274)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Fecha de Consulta"
        '
        'dtpFechaConsulta
        '
        Me.dtpFechaConsulta.Location = New System.Drawing.Point(191, 274)
        Me.dtpFechaConsulta.Name = "dtpFechaConsulta"
        Me.dtpFechaConsulta.Size = New System.Drawing.Size(200, 20)
        Me.dtpFechaConsulta.TabIndex = 7
        '
        'btnAgregarCita
        '
        Me.btnAgregarCita.Location = New System.Drawing.Point(91, 364)
        Me.btnAgregarCita.Name = "btnAgregarCita"
        Me.btnAgregarCita.Size = New System.Drawing.Size(75, 23)
        Me.btnAgregarCita.TabIndex = 8
        Me.btnAgregarCita.Text = "Agregar Cita"
        Me.btnAgregarCita.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Location = New System.Drawing.Point(263, 364)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelar.TabIndex = 9
        Me.btnCancelar.Text = "Salir"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'frmAgregarCitas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(497, 429)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnAgregarCita)
        Me.Controls.Add(Me.dtpFechaConsulta)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cmbDoctor)
        Me.Controls.Add(Me.Doctor)
        Me.Controls.Add(Me.cmbArea)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblPaciente)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmAgregarCitas"
        Me.Text = "frmAgregarCitas"
        CType(Me.bdCitas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblPaciente As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbArea As System.Windows.Forms.ComboBox
    Friend WithEvents cmbDoctor As System.Windows.Forms.ComboBox
    Friend WithEvents Doctor As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dtpFechaConsulta As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnAgregarCita As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents bdCitas As System.Windows.Forms.BindingSource
End Class
