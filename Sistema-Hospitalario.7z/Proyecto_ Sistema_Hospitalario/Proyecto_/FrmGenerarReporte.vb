Public Class FrmGenerarReporte

End Class