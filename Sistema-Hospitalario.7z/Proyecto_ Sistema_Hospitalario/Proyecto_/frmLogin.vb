Imports System.Data
Imports System.Data.OleDb
Public Class frmLogin
    Dim Admon As New frmAdministrador
    Dim Medico As New frmMedico
    Public idUsuario As Integer

    Private cadenaConexion As String = _
                "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & _
                    Application.StartupPath & "\bdHospital.accdb'"
    Friend conexion As OleDbConnection


    Friend dsHospital As DataSet

    Friend daPacientes As OleDbDataAdapter
    Friend daHistoriales As OleDbDataAdapter
    Friend daDoctores As OleDbDataAdapter
    Friend daCitas As OleDbDataAdapter
    Friend daCupos As OleDbDataAdapter
    Friend daEspecialidades As OleDbDataAdapter
    Friend cmbPacientes As OleDbCommandBuilder
    Friend cmbHistoriales As OleDbCommandBuilder
    Friend cmbDoctores As OleDbCommandBuilder
    Friend cmbCitas As OleDbCommandBuilder
    Friend cmbCupos As OleDbCommandBuilder
    Friend cmbEspecialidades As OleDbCommandBuilder
    Private Sub btnIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresar.Click
        If Me.tbidEmpleado.Text = "" Or Me.tbcontrase�a.Text = "" Then
            MessageBox.Show("Campos Vacios", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
            vaciarCampos()
        Else
            If Me.tbidEmpleado.Text = "0101" And Me.tbcontrase�a.Text = "1" Then

                vaciarCampos()
                Me.Hide()
                Admon.ShowDialog()
            Else

                If Me.tbidEmpleado.Text <> String.Empty Or Me.tbcontrase�a.Text <> String.Empty Then
                    Dim conexion As New OleDbConnection(cadenaConexion)
                    Dim SQL As String = "SELECT * FROM tblDoctores " & _
                        "WHERE IdDoctor = " & Me.tbidEmpleado.Text & _
                        " AND Contrase�aIngreso = '" & Me.tbcontrase�a.Text & "'"


                    Dim comandoSQL As New OleDbCommand(SQL, conexion)
                    Dim lectorDatos As OleDbDataReader

                    conexion.Open()

                    lectorDatos = comandoSQL.ExecuteReader()

                    If lectorDatos.Read() Then

                        Me.idUsuario = lectorDatos.GetInt32(0)
                        My.Forms.frmMedico.lblDoctor.Text = lectorDatos.GetString(1)
                        conexion.Close()
                        vaciarCampos()
                        Me.Hide()
                        My.Forms.frmMedico.ShowDialog()

                    Else
                        MessageBox.Show("Datos Incorrectos", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        vaciarCampos()
                        lectorDatos.Close()
                    End If

                End If
            End If
        End If
        'Me.Close()
    End Sub
    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.conexion = New OleDbConnection(cadenaConexion)
        Me.dsHospital = New DataSet("dsHospital")

        Me.daPacientes = New OleDbDataAdapter("SELECT * FROM tblPacientes", Me.conexion)
        Me.daPacientes.Fill(Me.dsHospital, "tblPacientes")
        Me.daPacientes.FillSchema(Me.dsHospital.Tables("tblPacientes"), SchemaType.Source)
        Me.cmbPacientes = New OleDbCommandBuilder(Me.daPacientes)


        Me.daHistoriales = New OleDbDataAdapter("SELECT * FROM tblHistoriales", conexion)
        Me.daHistoriales.Fill(Me.dsHospital, "tblHistoriales")
        Me.daHistoriales.FillSchema(Me.dsHospital.Tables("tblHistoriales"), SchemaType.Source)
        Me.cmbHistoriales = New OleDbCommandBuilder(Me.daHistoriales)


        Me.daDoctores = New OleDbDataAdapter("SELECT * FROM tblDoctores", conexion)
        Me.daDoctores.Fill(Me.dsHospital, "tblDoctores")
        Me.daDoctores.FillSchema(Me.dsHospital.Tables("tblDoctores"), SchemaType.Source)
        Me.cmbDoctores = New OleDbCommandBuilder(Me.daDoctores)

        Me.daCitas = New OleDbDataAdapter("SELECT * FROM tblCitas", conexion)
        Me.daCitas.Fill(Me.dsHospital, "tblCitas")
        Me.daCitas.FillSchema(Me.dsHospital.Tables("tblCitas"), SchemaType.Source)
        Me.cmbCitas = New OleDbCommandBuilder(Me.daCitas)


        Me.daCupos = New OleDbDataAdapter("SELECT * FROM tblCupos", conexion)
        Me.daCupos.Fill(Me.dsHospital, "tblCupos")
        Me.daCupos.FillSchema(Me.dsHospital.Tables("tblCupos"), SchemaType.Source)
        Me.cmbCupos = New OleDbCommandBuilder(Me.daCupos)


        Me.daEspecialidades = New OleDbDataAdapter("SELECT * FROM tblEspecialidades", conexion)
        Me.daEspecialidades.Fill(Me.dsHospital, "tblEspecialidades")
        Me.daEspecialidades.FillSchema(Me.dsHospital.Tables("tblEspecialidades"), SchemaType.Source)
        Me.cmbEspecialidades = New OleDbCommandBuilder(Me.daEspecialidades)


        Me.dsHospital.Tables("tblPacientes").PrimaryKey(0).AutoIncrementSeed = -1
        Me.dsHospital.Tables("tblPacientes").PrimaryKey(0).AutoIncrementStep = -1

        Me.dsHospital.Tables("tblDoctores").PrimaryKey(0).AutoIncrementSeed = -1
        Me.dsHospital.Tables("tblDoctores").PrimaryKey(0).AutoIncrementStep = -1


        Me.dsHospital.Tables("tblEspecialidades").PrimaryKey(0).AutoIncrementSeed = -1
        Me.dsHospital.Tables("tblEspecialidades").PrimaryKey(0).AutoIncrementStep = -1



        Me.dsHospital.Tables("tblHistoriales").PrimaryKey(0).AutoIncrementSeed = -1
        Me.dsHospital.Tables("tblHistoriales").PrimaryKey(0).AutoIncrementStep = -1
    End Sub

    Private Sub tbidEmpleado_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbidEmpleado.KeyPress
        If Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57 Then
        Else
            If Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = ChrW(0)
            End If
        End If
    End Sub

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()

    End Sub
    Private Sub vaciarCampos()
        Me.tbidEmpleado.Text = ""
        Me.tbcontrase�a.Text = ""
    End Sub
End Class