Imports System.Data
Imports System.Data.OleDb
Public Class frmManejarHistorial
    Friend dsHospital As New DataSet
    Friend daCitas As OleDbDataAdapter
    Friend cmbCitas As OleDbCommandBuilder
    Public idpaciente As Integer
    Public idUsuario As Integer
    Private cadenaConexion As String = _
              "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" & _
                  Application.StartupPath & "\bdHospital.accdb'"
    Private conexion As OleDbConnection

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
        frmMedico.Show()

    End Sub

    Private Sub btnAgregarHistorial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarHistorial.Click
        Me.dgvDatos.Focus()


        Dim fls As Integer = Convert.ToInt32(Me.dgvDatos.CurrentRow.Index)
        Me.idpaciente = Me.dgvDatos.Rows(fls).Cells(1).Value


        My.Forms.frmAgregarHistorial.obtneridpaciente(Me.idpaciente)
        My.Forms.frmAgregarHistorial.lblPaciente.Text = Me.dgvDatos.Rows(Me.dgvDatos.CurrentRow.Index).Cells("nombrePaciente").Value
        Me.Hide()
        frmAgregarHistorial.ShowDialog()


    End Sub

    Private Sub btnHistorial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHistorial.Click
        Me.dgvDatos.Focus()


        Dim fls As Integer = Convert.ToInt32(Me.dgvDatos.CurrentRow.Index)
        Me.idpaciente = Me.dgvDatos.Rows(fls).Cells(1).Value


        My.Forms.frmHistorialPaciente.obtneridpacienteHistoriales(Me.idpaciente)
        'frmAgregarHistorial.Show()
        frmHistorialPaciente.Show()
    End Sub

    Private Sub frmManejarHistorial_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.dgvDatos.DataSource = Nothing
        Me.idUsuario = My.Forms.frmLogin.idUsuario
        Me.dsHospital = New DataSet("dsHospital")
        Me.conexion = New OleDbConnection(cadenaConexion)


        Me.daCitas = New OleDbDataAdapter("SELECT tblCitas.IdCitas, tblCitas.idPaciente, tblCitas.idDoctor, tblPacientes.nombrePaciente,tblCitas.Fecha FROM tblPacientes INNER JOIN tblCitas ON tblPacientes.IdPaciente = tblCitas.idPaciente", conexion)

        Me.daCitas.Fill(Me.dsHospital, "tblCitas")

        Me.daCitas.FillSchema(Me.dsHospital.Tables("tblCitas"), SchemaType.Source)
        Me.cmbCitas = New OleDbCommandBuilder(Me.daCitas)

        Me.tbnombrePaciente.PromptChar = " "
        Me.btnAgregarHistorial.Enabled = False
        Me.btnHistorial.Enabled = False

    End Sub

    Private Sub tbnombrePaciente_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbnombrePaciente.MouseClick
        Me.tbnombrePaciente.Select(0, 0)
    End Sub

    Private Sub btnBuscarPaciente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscarPaciente.Click
        If Me.tbnombrePaciente.Text = "" Then
            MessageBox.Show("Ingrese un Criterio de Busqueda", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.tbnombrePaciente.Text = ""
        Else

            Me.dsHospital.Tables("tblCitas").DefaultView.RowFilter = _
            "idDoctor= '" & Me.idUsuario & "'"

            Me.bdcitas.DataSource = Me.dsHospital.Tables("tblCitas")


            Dim filasEncontradas As DataRow()

            filasEncontradas = Me.dsHospital.Tables("tblCitas").Select( _
                "nombrePaciente LIKE '%" & Me.tbnombrePaciente.Text & "%'")

            If filasEncontradas.Length > 0 Then
                Me.bdcitas.Position = _
                    Me.dsHospital.Tables("tblCitas").Rows.IndexOf(filasEncontradas(0))



                Me.dgvDatos.DataSource = Me.bdcitas
                Me.dgvDatos.Columns("Idcitas").Visible = False
                Me.dgvDatos.Columns("idDoctor").Visible = False
                Me.dgvDatos.Columns("nombrePaciente").HeaderText = "Nombre de Paciente"
                Me.dgvDatos.Columns("Fecha").Visible = False

                Me.dgvDatos.Columns("nombrePaciente").ReadOnly = True
                Me.dgvDatos.Columns("nombrePaciente").MinimumWidth = 300
                Me.dgvDatos.Columns("idPaciente").ReadOnly = True
                Me.btnAgregarHistorial.Enabled = True
                Me.btnHistorial.Enabled = True

                Me.tbnombrePaciente.Text = ""

            Else
                MsgBox("No se encontro paciente")
                Me.dgvDatos.DataSource = Nothing
                Me.tbnombrePaciente.Text = ""
            End If
        End If
    End Sub



    Private Sub dgvDatos_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvDatos.CellClick
        Me.dgvDatos.Focus()


        Dim fls As Integer = Convert.ToInt32(Me.dgvDatos.CurrentRow.Index)
        Me.idpaciente = Me.dgvDatos.Rows(fls).Cells(1).Value
        My.Forms.frmHistorialPaciente.lblPaciente.Text = Me.dgvDatos.Rows(fls).Cells("nombrePaciente").Value

    End Sub

    Public Function idpersona() As Integer
        Return idpaciente
    End Function

    Private Sub tbnombrePaciente_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbnombrePaciente.KeyPress
        If Not Char.IsLetter(e.KeyChar) And e.KeyChar <> vbBack Then
            e.Handled = True
        End If
    End Sub
End Class