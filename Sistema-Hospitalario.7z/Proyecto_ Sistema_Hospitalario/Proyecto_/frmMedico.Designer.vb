<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMedico
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDoctor = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnVerHistoria = New System.Windows.Forms.Button
        Me.btnVerCitas = New System.Windows.Forms.Button
        Me.btnSalir = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDoctor
        '
        Me.lblDoctor.AutoSize = True
        Me.lblDoctor.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDoctor.Location = New System.Drawing.Point(264, 40)
        Me.lblDoctor.Name = "lblDoctor"
        Me.lblDoctor.Size = New System.Drawing.Size(65, 24)
        Me.lblDoctor.TabIndex = 3
        Me.lblDoctor.Text = "Doctor"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(87, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(171, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Bienvenido Doctor:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnVerHistoria)
        Me.GroupBox1.Controls.Add(Me.btnVerCitas)
        Me.GroupBox1.Location = New System.Drawing.Point(58, 100)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(308, 100)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Selecione Que Desea Hacer"
        '
        'btnVerHistoria
        '
        Me.btnVerHistoria.Location = New System.Drawing.Point(165, 48)
        Me.btnVerHistoria.Name = "btnVerHistoria"
        Me.btnVerHistoria.Size = New System.Drawing.Size(117, 23)
        Me.btnVerHistoria.TabIndex = 5
        Me.btnVerHistoria.Text = "Ver Mis Pacientes"
        Me.btnVerHistoria.UseVisualStyleBackColor = True
        '
        'btnVerCitas
        '
        Me.btnVerCitas.Location = New System.Drawing.Point(18, 48)
        Me.btnVerCitas.Name = "btnVerCitas"
        Me.btnVerCitas.Size = New System.Drawing.Size(117, 23)
        Me.btnVerCitas.TabIndex = 4
        Me.btnVerCitas.Text = "Ver Mis Citas"
        Me.btnVerCitas.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Location = New System.Drawing.Point(166, 206)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(105, 23)
        Me.btnSalir.TabIndex = 6
        Me.btnSalir.Text = "Salir del Sistema"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'frmMedico
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(446, 262)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblDoctor)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmMedico"
        Me.Text = "frmMedico"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDoctor As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnVerHistoria As System.Windows.Forms.Button
    Friend WithEvents btnVerCitas As System.Windows.Forms.Button
    Friend WithEvents btnSalir As System.Windows.Forms.Button
End Class
