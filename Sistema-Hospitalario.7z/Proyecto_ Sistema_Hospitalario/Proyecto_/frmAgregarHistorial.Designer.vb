<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAgregarHistorial
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblPaciente = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.tbEnfermedad = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.tbTratamiento = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker
        Me.btnAgregarHist = New System.Windows.Forms.Button
        Me.btnSalir = New System.Windows.Forms.Button
        Me.bdAgregarHistorial = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.bdAgregarHistorial, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(91, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(253, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Agregar Historial Medico Para:"
        '
        'lblPaciente
        '
        Me.lblPaciente.AutoSize = True
        Me.lblPaciente.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaciente.Location = New System.Drawing.Point(350, 49)
        Me.lblPaciente.Name = "lblPaciente"
        Me.lblPaciente.Size = New System.Drawing.Size(77, 21)
        Me.lblPaciente.TabIndex = 1
        Me.lblPaciente.Text = "Paciente"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(58, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Enfermedad"
        '
        'tbEnfermedad
        '
        Me.tbEnfermedad.Location = New System.Drawing.Point(167, 137)
        Me.tbEnfermedad.Name = "tbEnfermedad"
        Me.tbEnfermedad.Size = New System.Drawing.Size(210, 20)
        Me.tbEnfermedad.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(59, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Tratamiento"
        '
        'tbTratamiento
        '
        Me.tbTratamiento.Location = New System.Drawing.Point(167, 180)
        Me.tbTratamiento.Multiline = True
        Me.tbTratamiento.Name = "tbTratamiento"
        Me.tbTratamiento.Size = New System.Drawing.Size(210, 126)
        Me.tbTratamiento.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(59, 329)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Fecha"
        '
        'dtpFecha
        '
        Me.dtpFecha.Location = New System.Drawing.Point(167, 329)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(200, 20)
        Me.dtpFecha.TabIndex = 7
        '
        'btnAgregarHist
        '
        Me.btnAgregarHist.Location = New System.Drawing.Point(95, 408)
        Me.btnAgregarHist.Name = "btnAgregarHist"
        Me.btnAgregarHist.Size = New System.Drawing.Size(157, 23)
        Me.btnAgregarHist.TabIndex = 8
        Me.btnAgregarHist.Text = "Agregar al Historial"
        Me.btnAgregarHist.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Location = New System.Drawing.Point(270, 408)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(157, 23)
        Me.btnSalir.TabIndex = 9
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'frmAgregarHistorial
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(541, 443)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnAgregarHist)
        Me.Controls.Add(Me.dtpFecha)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbTratamiento)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbEnfermedad)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblPaciente)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmAgregarHistorial"
        Me.Text = "frmAgregarHistorial"
        CType(Me.bdAgregarHistorial, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblPaciente As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbEnfermedad As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbTratamiento As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnAgregarHist As System.Windows.Forms.Button
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents bdAgregarHistorial As System.Windows.Forms.BindingSource
End Class
