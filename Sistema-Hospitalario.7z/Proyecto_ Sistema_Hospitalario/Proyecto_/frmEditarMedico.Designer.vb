<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditarMedico
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.cboEspecialidad = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.tbDireccionMedico = New System.Windows.Forms.TextBox
        Me.tbapellidoMedico = New System.Windows.Forms.MaskedTextBox
        Me.tbnombreMedico = New System.Windows.Forms.MaskedTextBox
        Me.tbTelefonoMedico = New System.Windows.Forms.MaskedTextBox
        Me.btnSalir = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.btnAgregarMedico = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnBuscar = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.rbInactivo = New System.Windows.Forms.RadioButton
        Me.rbActivo = New System.Windows.Forms.RadioButton
        Me.Label9 = New System.Windows.Forms.Label
        Me.tbContraseñaMedico = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.bdMedicos = New System.Windows.Forms.BindingSource(Me.components)
        Me.tbidMedico = New System.Windows.Forms.MaskedTextBox
        Me.tbCorreo = New System.Windows.Forms.MaskedTextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.btnNuevaBusqueda = New System.Windows.Forms.Button
        CType(Me.bdMedicos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cboEspecialidad
        '
        Me.cboEspecialidad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEspecialidad.FormattingEnabled = True
        Me.cboEspecialidad.Location = New System.Drawing.Point(99, 343)
        Me.cboEspecialidad.Name = "cboEspecialidad"
        Me.cboEspecialidad.Size = New System.Drawing.Size(121, 21)
        Me.cboEspecialidad.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(26, 346)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Especialidad"
        '
        'tbDireccionMedico
        '
        Me.tbDireccionMedico.Location = New System.Drawing.Point(97, 229)
        Me.tbDireccionMedico.Multiline = True
        Me.tbDireccionMedico.Name = "tbDireccionMedico"
        Me.tbDireccionMedico.Size = New System.Drawing.Size(153, 66)
        Me.tbDireccionMedico.TabIndex = 8
        '
        'tbapellidoMedico
        '
        Me.tbapellidoMedico.Location = New System.Drawing.Point(95, 90)
        Me.tbapellidoMedico.Mask = "??????????????????????????????????????????????????????????"
        Me.tbapellidoMedico.Name = "tbapellidoMedico"
        Me.tbapellidoMedico.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbapellidoMedico.Size = New System.Drawing.Size(153, 20)
        Me.tbapellidoMedico.TabIndex = 6
        '
        'tbnombreMedico
        '
        Me.tbnombreMedico.Location = New System.Drawing.Point(95, 47)
        Me.tbnombreMedico.Mask = "?????????????????????????????????????????????????????????'"
        Me.tbnombreMedico.Name = "tbnombreMedico"
        Me.tbnombreMedico.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbnombreMedico.Size = New System.Drawing.Size(153, 20)
        Me.tbnombreMedico.TabIndex = 4
        '
        'tbTelefonoMedico
        '
        Me.tbTelefonoMedico.Location = New System.Drawing.Point(97, 301)
        Me.tbTelefonoMedico.Mask = "9999-99-99"
        Me.tbTelefonoMedico.Name = "tbTelefonoMedico"
        Me.tbTelefonoMedico.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbTelefonoMedico.Size = New System.Drawing.Size(153, 20)
        Me.tbTelefonoMedico.TabIndex = 10
        '
        'btnSalir
        '
        Me.btnSalir.Location = New System.Drawing.Point(231, 446)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(75, 23)
        Me.btnSalir.TabIndex = 20
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Location = New System.Drawing.Point(133, 446)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.btnCancelar.TabIndex = 19
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'btnAgregarMedico
        '
        Me.btnAgregarMedico.Location = New System.Drawing.Point(42, 446)
        Me.btnAgregarMedico.Name = "btnAgregarMedico"
        Me.btnAgregarMedico.Size = New System.Drawing.Size(75, 23)
        Me.btnAgregarMedico.TabIndex = 18
        Me.btnAgregarMedico.Text = "Actualizar"
        Me.btnAgregarMedico.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 301)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Telefono"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(26, 229)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Direccion"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Apellido"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nombre"
        '
        'btnBuscar
        '
        Me.btnBuscar.Location = New System.Drawing.Point(286, 9)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(89, 23)
        Me.btnBuscar.TabIndex = 2
        Me.btnBuscar.Text = "Buscar Medico"
        Me.btnBuscar.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "ID Medico"
        '
        'rbInactivo
        '
        Me.rbInactivo.AutoSize = True
        Me.rbInactivo.Location = New System.Drawing.Point(99, 404)
        Me.rbInactivo.Name = "rbInactivo"
        Me.rbInactivo.Size = New System.Drawing.Size(69, 17)
        Me.rbInactivo.TabIndex = 15
        Me.rbInactivo.TabStop = True
        Me.rbInactivo.Text = "Inanctivo"
        Me.rbInactivo.UseVisualStyleBackColor = True
        '
        'rbActivo
        '
        Me.rbActivo.AutoSize = True
        Me.rbActivo.Location = New System.Drawing.Point(99, 381)
        Me.rbActivo.Name = "rbActivo"
        Me.rbActivo.Size = New System.Drawing.Size(55, 17)
        Me.rbActivo.TabIndex = 14
        Me.rbActivo.TabStop = True
        Me.rbActivo.Text = "Activo"
        Me.rbActivo.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(26, 408)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 13)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "Estado"
        '
        'tbContraseñaMedico
        '
        Me.tbContraseñaMedico.Location = New System.Drawing.Point(99, 178)
        Me.tbContraseñaMedico.Name = "tbContraseñaMedico"
        Me.tbContraseñaMedico.Size = New System.Drawing.Size(151, 20)
        Me.tbContraseñaMedico.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(26, 185)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "Contraseña"
        '
        'tbidMedico
        '
        Me.tbidMedico.Location = New System.Drawing.Point(97, 12)
        Me.tbidMedico.Mask = "99999999999999999"
        Me.tbidMedico.Name = "tbidMedico"
        Me.tbidMedico.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbidMedico.Size = New System.Drawing.Size(151, 20)
        Me.tbidMedico.TabIndex = 1
        '
        'tbCorreo
        '
        Me.tbCorreo.Location = New System.Drawing.Point(97, 132)
        Me.tbCorreo.Name = "tbCorreo"
        Me.tbCorreo.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.tbCorreo.Size = New System.Drawing.Size(153, 20)
        Me.tbCorreo.TabIndex = 22
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(26, 139)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "Correo"
        '
        'btnNuevaBusqueda
        '
        Me.btnNuevaBusqueda.Location = New System.Drawing.Point(268, 44)
        Me.btnNuevaBusqueda.Name = "btnNuevaBusqueda"
        Me.btnNuevaBusqueda.Size = New System.Drawing.Size(127, 23)
        Me.btnNuevaBusqueda.TabIndex = 23
        Me.btnNuevaBusqueda.Text = "Nueva Busqueda"
        Me.btnNuevaBusqueda.UseVisualStyleBackColor = True
        '
        'frmEditarMedico
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(407, 481)
        Me.Controls.Add(Me.btnNuevaBusqueda)
        Me.Controls.Add(Me.tbCorreo)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.tbidMedico)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.tbContraseñaMedico)
        Me.Controls.Add(Me.rbInactivo)
        Me.Controls.Add(Me.rbActivo)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.cboEspecialidad)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbDireccionMedico)
        Me.Controls.Add(Me.tbapellidoMedico)
        Me.Controls.Add(Me.tbnombreMedico)
        Me.Controls.Add(Me.tbTelefonoMedico)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnAgregarMedico)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmEditarMedico"
        Me.Text = "frmModificarMedico"
        CType(Me.bdMedicos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cboEspecialidad As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tbDireccionMedico As System.Windows.Forms.TextBox
    Friend WithEvents tbapellidoMedico As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbnombreMedico As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbTelefonoMedico As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents btnAgregarMedico As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents rbInactivo As System.Windows.Forms.RadioButton
    Friend WithEvents rbActivo As System.Windows.Forms.RadioButton
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbContraseñaMedico As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents bdMedicos As System.Windows.Forms.BindingSource
    Friend WithEvents tbidMedico As System.Windows.Forms.MaskedTextBox
    Friend WithEvents tbCorreo As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnNuevaBusqueda As System.Windows.Forms.Button
End Class
